#include "screen.h"
#include "model.h" 
#include "view.h" 
#include "controller.h"
#include <stdio.h>


int Setup()
{
	//initConsole();
	initWindow("Tetris",400,200,519,420);
	actionmusic();
	
	chief(); 
	random();
	initialization(x,y);
	initac();
	
	registerMouseEvent(mouseBack);
	registerKeyboardEvent(&speedModi);
	
	return 0; 
}

