#ifndef _MODEL_H_
#define _MODEL_H_

#include <stdbool.h>

extern int next;
extern int current;
extern int score;
extern int grade;
extern int x;
extern int y;
extern int num;
extern int speed;
bool furtf; 
int xi;
int yi;

extern int  y10,y30,y50,y70,y90,y110,y130,y150,y170,y190,y210,y230,y250,y270,y290,y310,y330,y350,y370,y390;

int a;
int c;
int d;
int e;
int f;
int g;

bool a1tf;
bool a2tf;
bool a3tf;
bool a4tf;
bool c1tf;
bool c2tf;
bool c3tf;
bool c4tf;
bool d1tf;
bool d2tf;
bool e1tf;
bool e2tf;
bool f1tf;
bool f2tf;
bool g1tf;
bool g2tf;
bool g3tf;
bool g4tf;

extern int list[100000][4];

extern const int xbot[15];
extern const int ybot[20];

//19��ͼ�α����Ĵ洢
extern int a1[4][2];
extern int a2[4][2];
extern int a3[4][2];
extern int a4[4][2];
extern int b1[4][2];
extern int c1[4][2];
extern int c2[4][2];
extern int c3[4][2];
extern int c4[4][2];
extern int d1[4][2];
extern int d2[4][2];
extern int e1[4][2];
extern int e2[4][2];
extern int f1[4][2];
extern int f2[4][2];
extern int g1[4][2];
extern int g2[4][2];
extern int g3[4][2];
extern int g4[4][2]; 


//��ά�����ʼ����ֵ����ԭ������ 
void lina1(int x,int y);
void lina2(int x,int y);
void lina3(int x,int y);
void lina4(int x,int y);
void linb1(int x,int y);
void linc1(int x,int y);
void linc2(int x,int y);
void linc3(int x,int y);
void linc4(int x,int y);
void lind1(int x,int y);
void lind2(int x,int y);
void line1(int x,int y);
void line2(int x,int y);
void linf1(int x,int y);
void linf2(int x,int y);
void ling1(int x,int y);
void ling2(int x,int y);
void ling3(int x,int y);
void ling4(int x,int y);

void sqmumber (); 

void initac();
void initialization (int x,int y);

#endif
