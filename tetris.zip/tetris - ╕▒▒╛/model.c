#include "model.h" 
#include <stdbool.h>

/*ȫ�ֱ�����ͳһ����*/
int next;//������һ������ͼ�ε����������
int current;//���嵱ǰͼ�ε���������� 
int score=0;//���嵱ǰ�����ı���
int grade=1;//���嵱ǰ�ȼ�
int x=150;//����ͼ�����Ϸ���x���� 
int y=10;//����ͼ�����Ϸ���y����
int num=0;//����ͼ���ܸ��� 
int speed=20;//λ�Ʊ���
bool furtf=false;//����ˢ�µĿ��� 
int xi=395;
int yi=185;

/*����任ͼ�ε�ѡ���ʶ*/
int a=1;
//ͼ��b�������ޱ任��������
int c=1;
int d=1;
int e=1;
int f=1;
int g=1;

bool a1tf;
bool a2tf;
bool a3tf;
bool a4tf;
bool c1tf;
bool c2tf;
bool c3tf;
bool c4tf;
bool d1tf;
bool d2tf;
bool e1tf;
bool e2tf;
bool f1tf;
bool f2tf;
bool g1tf;
bool g2tf;
bool g3tf;
bool g4tf;


void initac()//��ʼ������
{
	a=1;
	c=1;
	d=1;
	e=1;
	f=1;
	g=1;
	a1tf=false;
	a2tf=false;
	a3tf=false;
	a4tf=false;
	c1tf=false;
	c2tf=false;
	c3tf=false;
	c4tf=false;
	d1tf=false;
	d2tf=false;
	e1tf=false;
	e2tf=false;
	f1tf=false;
	f2tf=false;
	g1tf=false;
	g2tf=false;
	g3tf=false;
	g4tf=false;
} 

//����������ÿ��square����
int  y10=0,y30=0,y50=0,y70=0,y90=0,y110=0,y130=0,y150=0,y170=0,y190=0,y210=0,y230=0,y250=0,y270=0,y290=0,y310=0,y330=0,y350=0,y370=0,y390=0;

void sqmumber ()//��¼����square���� 
{
	switch(current)
	{
		case 0:
		{
			int i;
			for(i=0;i<4;i++)
			{
				if(a==1)
				{
					switch(a1[i][1])
					{
						case 10:
							y10++;
							break;
						case 30:
							y30++;
							break;
						case 50:
							y50++;
							break;
						case 70:
							y70++;
							break;
						case 90:
							y90++;
							break;
						case 110:
							y110++;
							break;
						case 130:
							y130++;
							break;
						case 150:
							y150++;
							break;
						case 170:
							y170++;
							break;
						case 190:
							y190++;
							break;
						case 210:
							y210++;
							break;
						case 230:
							y230++;
							break;		
						case 250:
							y250++;
							break;
						case 270:
							y270++;
							break;
						case 290:
							y290++;
							break;
						case 310:
							y310++;
							break;
						case 330:
							y330++;
							break;
						case 350:
							y350++;
							break;
						case 370:
							y370++;
							break;
						case 390:
							y390++;
							break;
					}					
				}
				
				else if(a==2)
				{
					switch(a2[i][1])
					{
						case 10:
							y10++;
							break;
						case 30:
							y30++;
							break;
						case 50:
							y50++;
							break;
						case 70:
							y70++;
							break;
						case 90:
							y90++;
							break;
						case 110:
							y110++;
							break;
						case 130:
							y130++;
							break;
						case 150:
							y150++;
							break;
						case 170:
							y170++;
							break;
						case 190:
							y190++;
							break;
						case 210:
							y210++;
							break;
						case 230:
							y230++;
							break;		
						case 250:
							y250++;
							break;
						case 270:
							y270++;
							break;
						case 290:
							y290++;
							break;
						case 310:
							y310++;
							break;
						case 330:
							y330++;
							break;
						case 350:
							y350++;
							break;
						case 370:
							y370++;
							break;
						case 390:
							y390++;
							break;
					}					
				}
				
				else if(a==3)
				{
					switch(a3[i][1])
					{
						case 10:
							y10++;
							break;
						case 30:
							y30++;
							break;
						case 50:
							y50++;
							break;
						case 70:
							y70++;
							break;
						case 90:
							y90++;
							break;
						case 110:
							y110++;
							break;
						case 130:
							y130++;
							break;
						case 150:
							y150++;
							break;
						case 170:
							y170++;
							break;
						case 190:
							y190++;
							break;
						case 210:
							y210++;
							break;
						case 230:
							y230++;
							break;		
						case 250:
							y250++;
							break;
						case 270:
							y270++;
							break;
						case 290:
							y290++;
							break;
						case 310:
							y310++;
							break;
						case 330:
							y330++;
							break;
						case 350:
							y350++;
							break;
						case 370:
							y370++;
							break;
						case 390:
							y390++;
							break;
					}					
				}
				
				else if(a==4)
				{
					switch(a4[i][1])
					{
						case 10:
							y10++;
							break;
						case 30:
							y30++;
							break;
						case 50:
							y50++;
							break;
						case 70:
							y70++;
							break;
						case 90:
							y90++;
							break;
						case 110:
							y110++;
							break;
						case 130:
							y130++;
							break;
						case 150:
							y150++;
							break;
						case 170:
							y170++;
							break;
						case 190:
							y190++;
							break;
						case 210:
							y210++;
							break;
						case 230:
							y230++;
							break;		
						case 250:
							y250++;
							break;
						case 270:
							y270++;
							break;
						case 290:
							y290++;
							break;
						case 310:
							y310++;
							break;
						case 330:
							y330++;
							break;
						case 350:
							y350++;
							break;
						case 370:
							y370++;
							break;
						case 390:
							y390++;
							break;
					}					
				} 
		
			}			
			break;
		}
		case 1:
		{
			int i;
			for(i=0;i<4;i++)
			{
				switch(b1[i][1])
				{
					case 10:
						y10++;
						break;
					case 30:
						y30++;
						break;
					case 50:
						y50++;
						break;
					case 70:
						y70++;
						break;
					case 90:
						y90++;
						break;
					case 110:
						y110++;
						break;
					case 130:
						y130++;
						break;
					case 150:
						y150++;
						break;
					case 170:
						y170++;
						break;
					case 190:
						y190++;
						break;
					case 210:
						y210++;
						break;
					case 230:
						y230++;
						break;		
					case 250:
						y250++;
						break;
					case 270:
						y270++;
						break;
					case 290:
						y290++;
						break;
					case 310:
						y310++;
						break;
					case 330:
						y330++;
						break;
					case 350:
						y350++;
						break;
					case 370:
						y370++;
						break;
					case 390:
						y390++;
						break;
				}		
			}			
			break;
		}	
		case 2:
		{
			int i;
			for(i=0;i<4;i++)
			{
				if(c==1)
				{
					switch(c1[i][1])
					{
						case 10:
							y10++;
							break;
						case 30:
							y30++;
							break;
						case 50:
							y50++;
							break;
						case 70:
							y70++;
							break;
						case 90:
							y90++;
							break;
						case 110:
							y110++;
							break;
						case 130:
							y130++;
							break;
						case 150:
							y150++;
							break;
						case 170:
							y170++;
							break;
						case 190:
							y190++;
							break;
						case 210:
							y210++;
							break;
						case 230:
							y230++;
							break;		
						case 250:
							y250++;
							break;
						case 270:
							y270++;
							break;
						case 290:
							y290++;
							break;
						case 310:
							y310++;
							break;
						case 330:
							y330++;
							break;
						case 350:
							y350++;
							break;
						case 370:
							y370++;
							break;
						case 390:
							y390++;
							break;
					}							
				}
				
				else if(c==2)
				{
					switch(c2[i][1])
					{
						case 10:
							y10++;
							break;
						case 30:
							y30++;
							break;
						case 50:
							y50++;
							break;
						case 70:
							y70++;
							break;
						case 90:
							y90++;
							break;
						case 110:
							y110++;
							break;
						case 130:
							y130++;
							break;
						case 150:
							y150++;
							break;
						case 170:
							y170++;
							break;
						case 190:
							y190++;
							break;
						case 210:
							y210++;
							break;
						case 230:
							y230++;
							break;		
						case 250:
							y250++;
							break;
						case 270:
							y270++;
							break;
						case 290:
							y290++;
							break;
						case 310:
							y310++;
							break;
						case 330:
							y330++;
							break;
						case 350:
							y350++;
							break;
						case 370:
							y370++;
							break;
						case 390:
							y390++;
							break;
					}												
				}
				
				else if(c==3)
				{
					switch(c3[i][1])
					{
						case 10:
							y10++;
							break;
						case 30:
							y30++;
							break;
						case 50:
							y50++;
							break;
						case 70:
							y70++;
							break;
						case 90:
							y90++;
							break;
						case 110:
							y110++;
							break;
						case 130:
							y130++;
							break;
						case 150:
							y150++;
							break;
						case 170:
							y170++;
							break;
						case 190:
							y190++;
							break;
						case 210:
							y210++;
							break;
						case 230:
							y230++;
							break;		
						case 250:
							y250++;
							break;
						case 270:
							y270++;
							break;
						case 290:
							y290++;
							break;
						case 310:
							y310++;
							break;
						case 330:
							y330++;
							break;
						case 350:
							y350++;
							break;
						case 370:
							y370++;
							break;
						case 390:
							y390++;
							break;
					}												
				}
				
				else if(c==4)
				{
					switch(c4[i][1])
					{
						case 10:
							y10++;
							break;
						case 30:
							y30++;
							break;
						case 50:
							y50++;
							break;
						case 70:
							y70++;
							break;
						case 90:
							y90++;
							break;
						case 110:
							y110++;
							break;
						case 130:
							y130++;
							break;
						case 150:
							y150++;
							break;
						case 170:
							y170++;
							break;
						case 190:
							y190++;
							break;
						case 210:
							y210++;
							break;
						case 230:
							y230++;
							break;		
						case 250:
							y250++;
							break;
						case 270:
							y270++;
							break;
						case 290:
							y290++;
							break;
						case 310:
							y310++;
							break;
						case 330:
							y330++;
							break;
						case 350:
							y350++;
							break;
						case 370:
							y370++;
							break;
						case 390:
							y390++;
							break;
					}												
				} 

			}			
			break;
		}
		case 3:
		{
			int i;
			for(i=0;i<4;i++)
			{
				if(d==1)
				{
					switch(d1[i][1])
					{
						case 10:
							y10++;
							break;
						case 30:
							y30++;
							break;
						case 50:
							y50++;
							break;
						case 70:
							y70++;
							break;
						case 90:
							y90++;
							break;
						case 110:
							y110++;
							break;
						case 130:
							y130++;
							break;
						case 150:
							y150++;
							break;
						case 170:
							y170++;
							break;
						case 190:
							y190++;
							break;
						case 210:
							y210++;
							break;
						case 230:
							y230++;
							break;		
						case 250:
							y250++;
							break;
						case 270:
							y270++;
							break;
						case 290:
							y290++;
							break;
						case 310:
							y310++;
							break;
						case 330:
							y330++;
							break;
						case 350:
							y350++;
							break;
						case 370:
							y370++;
							break;
						case 390:
							y390++;
							break;
					}							
				}
				
				else if(d==2)
				{
					switch(d2[i][1])
					{
						case 10:
							y10++;
							break;
						case 30:
							y30++;
							break;
						case 50:
							y50++;
							break;
						case 70:
							y70++;
							break;
						case 90:
							y90++;
							break;
						case 110:
							y110++;
							break;
						case 130:
							y130++;
							break;
						case 150:
							y150++;
							break;
						case 170:
							y170++;
							break;
						case 190:
							y190++;
							break;
						case 210:
							y210++;
							break;
						case 230:
							y230++;
							break;		
						case 250:
							y250++;
							break;
						case 270:
							y270++;
							break;
						case 290:
							y290++;
							break;
						case 310:
							y310++;
							break;
						case 330:
							y330++;
							break;
						case 350:
							y350++;
							break;
						case 370:
							y370++;
							break;
						case 390:
							y390++;
							break;
					}												
				}

			}			
			break;
		}	
		case 4:
		{
			int i;
			for(i=0;i<4;i++)
			{
				if(e==1)
				{
					switch(e1[i][1])
					{
						case 10:
							y10++;
							break;
						case 30:
							y30++;
							break;
						case 50:
							y50++;
							break;
						case 70:
							y70++;
							break;
						case 90:
							y90++;
							break;
						case 110:
							y110++;
							break;
						case 130:
							y130++;
							break;
						case 150:
							y150++;
							break;
						case 170:
							y170++;
							break;
						case 190:
							y190++;
							break;
						case 210:
							y210++;
							break;
						case 230:
							y230++;
							break;		
						case 250:
							y250++;
							break;
						case 270:
							y270++;
							break;
						case 290:
							y290++;
							break;
						case 310:
							y310++;
							break;
						case 330:
							y330++;
							break;
						case 350:
							y350++;
							break;
						case 370:
							y370++;
							break;
						case 390:
							y390++;
							break;
					}							
				}
				
				else if(e==2)
				{
					switch(e2[i][1])
					{
						case 10:
							y10++;
							break;
						case 30:
							y30++;
							break;
						case 50:
							y50++;
							break;
						case 70:
							y70++;
							break;
						case 90:
							y90++;
							break;
						case 110:
							y110++;
							break;
						case 130:
							y130++;
							break;
						case 150:
							y150++;
							break;
						case 170:
							y170++;
							break;
						case 190:
							y190++;
							break;
						case 210:
							y210++;
							break;
						case 230:
							y230++;
							break;		
						case 250:
							y250++;
							break;
						case 270:
							y270++;
							break;
						case 290:
							y290++;
							break;
						case 310:
							y310++;
							break;
						case 330:
							y330++;
							break;
						case 350:
							y350++;
							break;
						case 370:
							y370++;
							break;
						case 390:
							y390++;
							break;
					}										
				}

			}			
			break;
		}
		case 5:
		{
			int i;
			for(i=0;i<4;i++)
			{
				if(f==1)
				{
					switch(f1[i][1])
					{
						case 10:
							y10++;
							break;
						case 30:
							y30++;
							break;
						case 50:
							y50++;
							break;
						case 70:
							y70++;
							break;
						case 90:
							y90++;
							break;
						case 110:
							y110++;
							break;
						case 130:
							y130++;
							break;
						case 150:
							y150++;
							break;
						case 170:
							y170++;
							break;
						case 190:
							y190++;
							break;
						case 210:
							y210++;
							break;
						case 230:
							y230++;
							break;		
						case 250:
							y250++;
							break;
						case 270:
							y270++;
							break;
						case 290:
							y290++;
							break;
						case 310:
							y310++;
							break;
						case 330:
							y330++;
							break;
						case 350:
							y350++;
							break;
						case 370:
							y370++;
							break;
						case 390:
							y390++;
							break;
					}					
				}
				
				else if(f==2)
				{
					switch(f2[i][1])
					{
						case 10:
							y10++;
							break;
						case 30:
							y30++;
							break;
						case 50:
							y50++;
							break;
						case 70:
							y70++;
							break;
						case 90:
							y90++;
							break;
						case 110:
							y110++;
							break;
						case 130:
							y130++;
							break;
						case 150:
							y150++;
							break;
						case 170:
							y170++;
							break;
						case 190:
							y190++;
							break;
						case 210:
							y210++;
							break;
						case 230:
							y230++;
							break;		
						case 250:
							y250++;
							break;
						case 270:
							y270++;
							break;
						case 290:
							y290++;
							break;
						case 310:
							y310++;
							break;
						case 330:
							y330++;
							break;
						case 350:
							y350++;
							break;
						case 370:
							y370++;
							break;
						case 390:
							y390++;
							break;
					}					
				}
		
			}			
			break;
		}
		case 6:
		{
			int i;
			for(i=0;i<4;i++)
			{
				if(g==1)
				{
					switch(g1[i][1])
					{
						case 10:
							y10++;
							break;
						case 30:
							y30++;
							break;
						case 50:
							y50++;
							break;
						case 70:
							y70++;
							break;
						case 90:
							y90++;
							break;
						case 110:
							y110++;
							break;
						case 130:
							y130++;
							break;
						case 150:
							y150++;
							break;
						case 170:
							y170++;
							break;
						case 190:
							y190++;
							break;
						case 210:
							y210++;
							break;
						case 230:
							y230++;
							break;		
						case 250:
							y250++;
							break;
						case 270:
							y270++;
							break;
						case 290:
							y290++;
							break;
						case 310:
							y310++;
							break;
						case 330:
							y330++;
							break;
						case 350:
							y350++;
							break;
						case 370:
							y370++;
							break;
						case 390:
							y390++;
							break;
					}					
				}
				
				else if(g==2)
				{
					switch(g2[i][1])
					{
						case 10:
							y10++;
							break;
						case 30:
							y30++;
							break;
						case 50:
							y50++;
							break;
						case 70:
							y70++;
							break;
						case 90:
							y90++;
							break;
						case 110:
							y110++;
							break;
						case 130:
							y130++;
							break;
						case 150:
							y150++;
							break;
						case 170:
							y170++;
							break;
						case 190:
							y190++;
							break;
						case 210:
							y210++;
							break;
						case 230:
							y230++;
							break;		
						case 250:
							y250++;
							break;
						case 270:
							y270++;
							break;
						case 290:
							y290++;
							break;
						case 310:
							y310++;
							break;
						case 330:
							y330++;
							break;
						case 350:
							y350++;
							break;
						case 370:
							y370++;
							break;
						case 390:
							y390++;
							break;
					}					
				}
				
				else if(g==3)
				{
					switch(g3[i][1])
					{
						case 10:
							y10++;
							break;
						case 30:
							y30++;
							break;
						case 50:
							y50++;
							break;
						case 70:
							y70++;
							break;
						case 90:
							y90++;
							break;
						case 110:
							y110++;
							break;
						case 130:
							y130++;
							break;
						case 150:
							y150++;
							break;
						case 170:
							y170++;
							break;
						case 190:
							y190++;
							break;
						case 210:
							y210++;
							break;
						case 230:
							y230++;
							break;		
						case 250:
							y250++;
							break;
						case 270:
							y270++;
							break;
						case 290:
							y290++;
							break;
						case 310:
							y310++;
							break;
						case 330:
							y330++;
							break;
						case 350:
							y350++;
							break;
						case 370:
							y370++;
							break;
						case 390:
							y390++;
							break;
					}					
				}
				
				else if(g==4)
				{
					switch(g4[i][1])
					{
						case 10:
							y10++;
							break;
						case 30:
							y30++;
							break;
						case 50:
							y50++;
							break;
						case 70:
							y70++;
							break;
						case 90:
							y90++;
							break;
						case 110:
							y110++;
							break;
						case 130:
							y130++;
							break;
						case 150:
							y150++;
							break;
						case 170:
							y170++;
							break;
						case 190:
							y190++;
							break;
						case 210:
							y210++;
							break;
						case 230:
							y230++;
							break;		
						case 250:
							y250++;
							break;
						case 270:
							y270++;
							break;
						case 290:
							y290++;
							break;
						case 310:
							y310++;
							break;
						case 330:
							y330++;
							break;
						case 350:
							y350++;
							break;
						case 370:
							y370++;
							break;
						case 390:
							y390++;
							break;
					}					
				}
		
			}			
			break;
		}					
	}

} 

//����ͼ�ι���19�ֱ任�Ķ�ά����洢 
int a1[4][2]={};
int a2[4][2]={};
int a3[4][2]={};
int a4[4][2]={};
int b1[4][2]={};
int c1[4][2]={};
int c2[4][2]={};
int c3[4][2]={};
int c4[4][2]={};
int d1[4][2]={};
int d2[4][2]={};
int e1[4][2]={};
int e2[4][2]={};
int f1[4][2]={};
int f2[4][2]={};
int g1[4][2]={};
int g2[4][2]={};
int g3[4][2]={};
int g4[4][2]={};  

//��������ͼ�ι���19�ֱ任�Ķ�ά����洢����
void lina1(int x,int y)
{
	a1[0][0]=x;
	a1[0][1]=y;
	a1[1][0]=x;
	a1[1][1]=y+20;
	a1[2][0]=x+20;
	a1[2][1]=y+20;
	a1[3][0]=x+40;
	a1[3][1]=y+20;
}
void lina2(int x,int y)
{
	a2[0][0]=x;
	a2[0][1]=y;
	a2[1][0]=x+20;
	a2[1][1]=y;
	a2[2][0]=x;
	a2[2][1]=y+20;
	a2[3][0]=x;
	a2[3][1]=y+40;	
}
void lina3(int x,int y)
{
	a3[0][0]=x;
	a3[0][1]=y;
	a3[1][0]=x+20;
	a3[1][1]=y;
	a3[2][0]=x+40;
	a3[2][1]=y;
	a3[3][0]=x+40;
	a3[3][1]=y+20;
}
void lina4(int x,int y)
{
	a4[0][0]=x;
	a4[0][1]=y;
	a4[1][0]=x;
	a4[1][1]=y+20;
	a4[2][0]=x-20;
	a4[2][1]=y+40;
	a4[3][0]=x;
	a4[3][1]=y+40;
}
void linb1(int x,int y)
{
	b1[0][0]=x;
	b1[0][1]=y;
	b1[1][0]=x+20;
	b1[1][1]=y;
	b1[2][0]=x;
	b1[2][1]=y+20;
	b1[3][0]=x+20;
	b1[3][1]=y+20;
}
void linc1(int x,int y)
{
	c1[0][0]=x;
	c1[0][1]=y;
	c1[1][0]=x-20;
	c1[1][1]=y+20;
	c1[2][0]=x;
	c1[2][1]=y+20;	
	c1[3][0]=x;
	c1[3][1]=y+40;
} 
void linc2(int x,int y)
{
	c2[0][0]=x;
	c2[0][1]=y;
	c2[1][0]=x-20;
	c2[1][1]=y+20;
	c2[2][0]=x;
	c2[2][1]=y+20;
	c2[3][0]=x+20;
	c2[3][1]=y+20;
} 
void linc3(int x,int y)
{
	c3[0][0]=x;
	c3[0][1]=y;
	c3[1][0]=x;
	c3[1][1]=y+20;
	c3[2][0]=x+20;
	c3[2][1]=y+20;
	c3[3][0]=x;
	c3[3][1]=y+40;
} 
void linc4(int x,int y)
{	
	c4[0][0]=x;
	c4[0][1]=y;
	c4[1][0]=x+20;
	c4[1][1]=y;
	c4[2][0]=x+40;
	c4[2][1]=y;
	c4[3][0]=x+20;
	c4[3][1]=y+20;
} 
void lind1(int x,int y)
{
	d1[0][0]=x;
	d1[0][1]=y;
	d1[1][0]=x;
	d1[1][1]=y+20;
	d1[2][0]=x;
	d1[2][1]=y+40;
	d1[3][0]=x;
	d1[3][1]=y+60;
} 
void lind2(int x,int y)
{
	d2[0][0]=x;
	d2[0][1]=y;
	d2[1][0]=x+20;
	d2[1][1]=y;
	d2[2][0]=x+40;
	d2[2][1]=y;
	d2[3][0]=x+60;
	d2[3][1]=y;
}
void line1(int x,int y)
{
	e1[0][0]=x;
	e1[0][1]=y;
	e1[1][0]=x+20;
	e1[1][1]=y;
	e1[2][0]=x+20;
	e1[2][1]=y+20;
	e1[3][0]=x+40;
	e1[3][1]=y+20;
}
void line2(int x,int y)
{
	e2[0][0]=x;
	e2[0][1]=y;
	e2[1][0]=x;
	e2[1][1]=y+20;
	e2[2][0]=x-20;
	e2[2][1]=y+20;
	e2[3][0]=x-20;
	e2[3][1]=y+40;
}
void linf1(int x,int y)
{
	f1[0][0]=x;
	f1[0][1]=y;
	f1[1][0]=x+20;
	f1[1][1]=y;
	f1[2][0]=x-20;
	f1[2][1]=y+20;
	f1[3][0]=x;
	f1[3][1]=y+20;
}
void linf2(int x,int y)
{
	f2[0][0]=x;
	f2[0][1]=y;
	f2[1][0]=x;
	f2[1][1]=y+20;
	f2[2][0]=x+20;
	f2[2][1]=y+20;
	f2[3][0]=x+20;
	f2[3][1]=y+40;
}
void ling1(int x,int y)
{
	g1[0][0]=x;
	g1[0][1]=y;
	g1[1][0]=x-40;
	g1[1][1]=y+20;
	g1[2][0]=x-20;
	g1[2][1]=y+20;
	g1[3][0]=x;
	g1[3][1]=y+20;
}
void ling2(int x,int y)
{
	g2[0][0]=x;
	g2[0][1]=y;
	g2[1][0]=x;
	g2[1][1]=y+20;
	g2[2][0]=x;
	g2[2][1]=y+40;
	g2[3][0]=x+20;
	g2[3][1]=y+40;
}
void ling3(int x,int y)
{
	g3[0][0]=x;
	g3[0][1]=y;
	g3[1][0]=x+20;
	g3[1][1]=y;
	g3[2][0]=x+40;
	g3[2][1]=y;
	g3[3][0]=x;
	g3[3][1]=y+20;
}
void ling4(int x,int y)
{
	g4[0][0]=x;
	g4[0][1]=y;
	g4[1][0]=x+20;
	g4[1][1]=y;
	g4[2][0]=x+20;
	g4[2][1]=y+20;
	g4[3][0]=x+20;
	g4[3][1]=y+40;
}

void initialization (int x,int y)//��ʼ��ͼ������ 
{
	if(current==0)	
	{
		lina1(x,y);
	}
	else if(current==1)
	{
		linb1(x,y);		
	}
	else if(current==2)
	{
		linc1(x,y);	
	}	
	else if(current==3)
	{
		lind1(x,y);	
	}	
	else if(current==4)
	{
		line1(x,y);		
	}	
	else if(current==5)
	{
		linf1(x,y);		
	}	
	else if(current==6)
	{
		ling1(x,y);			
	}	
}
 
/*ȫ�����Ա�����*/
int list[100000][4];//x,y,coler,0&1

/*�洢ͼ�ο��������x,y����*/
const int xbot[15]={10,30,50,70,90,110,130,150,170,190,210,230,250,270,290,};
const int ybot[20]={10,30,50,70,90,110,130,150,170,190,210,230,250,270,290,310,330,350,370,390,};




 
 
