#ifndef _CONTROLLER_H_
#define _CONTROLLER_H_

#include "screen.h"
#include "model.h"

void optiona1();
void optiona2();
void optiona3();
void optiona4();
void optionb1();
void optionc1();
void optionc2();
void optionc3();
void optionc4();
void optiond1();
void optiond2();
void optione1();
void optione2();
void optionf1();
void optionf2();
void optiong1();
void optiong2();
void optiong3();
void optiong4();

void chief();
void minor(); 
void recovery();
viod gameover(); 
void nextimg(int xi,int yi);

int serch();
void rase(int linenum);

void actionmusic();

#endif
