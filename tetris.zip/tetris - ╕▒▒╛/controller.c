#include "controller.h"
#include "model.h"
#include "view.h"
#include "screen.h"
#include<time.h>
#include<stdio.h>
#include<stdlib.h>


//�����ܷ�����ƶ�����bool�� 0F.1T 
static int dbool=10;
static int lbool=10;
static int rbool=10;

static int xlite=0;
static int xbest=0;

static int bitrary()//������Ӻ���
{
	int deputy;
	srand(time(0));
	deputy=rand();
	deputy=deputy%10;
	return deputy;
} 

int random()//�����ͼ�� 
{
	if (num==0)
	{
		current=bitrary();
		while(current>6)
		{
			current=bitrary();
		} 
		next=bitrary();
		while(next>6||current==next)
		{
			next=bitrary();
		}
		return current;
	}
	else if(num!=0)
	{
		current=next; 
		next=bitrary();
		while(next>6||current==next)
		{
			next=bitrary();
		}
	}
}

//4����������ж�
int down1(int x1,int y1,int x2,int y2,int x3,int y3,int x4,int y4)
{
	if(y4==390)
	{
		return 0;			
	}
	int g;
	for(g=0;g<=num*4;g++)
	{
	    if(list[g][0]==x1&&list[g][1]==y1+20&&list[g][3]==1)
		//������������ҵ��˸÷�����һ�ν����y���� 
		{
			return 0;							
		}
		else if(num*4==g)
		//�����������û�ҵ��˸÷�����һ�ν����y���꣬���� 
		{
			return 1;
		}
	} 
	
} 

int down2(int x1,int y1,int x2,int y2,int x3,int y3,int x4,int y4)
{
	int g;
	if(y4==390)
	{
		return 0;			
	}
	for(g=0;g<=num*4;g++)
	{
	    if(list[g][0]==x2&&list[g][1]==y2+20&&list[g][3]==1)
		//������������ҵ��˸÷�����һ�ν����y���� �������顣 
		{
			return 0;							
		}
		else if(num*4==g)
		//�����������û�ҵ��˸÷�����һ�ν����y���꣬���� 
		{
			return 1;
		}
	} 	
} 

int down3(int x1,int y1,int x2,int y2,int x3,int y3,int x4,int y4)
{
	if(y4==390)
	{
		return 0;			
	}	
	int g;
	for(g=0;g<=num*4;g++)
	{
	    if(list[g][0]==x3&&list[g][1]==y3+20&&list[g][3]==1)
		//������������ҵ��˸÷�����һ�ν����y���� �������顣 
		{
			return 0;							
		}
		else if(num*4==g)
		//�����������û�ҵ��˸÷�����һ�ν����y���꣬���� 
		{
			return 1;
		}
	} 
} 

int down4(int x1,int y1,int x2,int y2,int x3,int y3,int x4,int y4)
{
	if(y4==390)
	{
		return 0;			
	}
	int g;
	for(g=0;g<=num*4;g++)
	{
	    if(list[g][0]==x4&&list[g][1]==y4+20&&list[g][3]==1)
		//������������ҵ��˸÷�����һ�ν����y���� �������顣 
		{
			return 0;							
		}
		else if(num*4==g)
		//�����������û�ҵ��˸÷�����һ�ν����y���꣬���� 
		{
			return 1;
		}
	} 	
} 

//4���������ж� 
int left1(int x1,int y1,int x2,int y2,int x3,int y3,int x4,int y4)
{
	//ȡ�ĸ�x�����е���Сֵ 
	xlite=(x1<=x2)?x1:x2;
	xlite=(xlite<=x3)?xlite:x3;
	xlite=(xlite<=x4)?xlite:x4;
	if(xlite==10)
	{
		return 0;			
	}
	int g;
	for(g=0;g<=num*4;g++)
	{
	    if(list[g][0]==x1-20&&list[g][1]==y1&&list[g][3]==1)
		//������������ҵ��˸÷�����һ�ν����y���� 
		{ 
			return 0;							
		}
		else if(num*4==g)
		//�����������û�ҵ��˸÷�����һ�ν����y���꣬���� 
		{
			return 1;
		}
	} 	
}
int left2(int x1,int y1,int x2,int y2,int x3,int y3,int x4,int y4)
{
	if(xlite==10)
	{
		return 0;			
	}
	int g;
	for(g=0;g<=num*4;g++)
	{
	    if(list[g][0]==x2-20&&list[g][1]==y2&&list[g][3]==1)
		//������������ҵ��˸÷�����һ�ν����y���� 
		{ 
			return 0;							
		}
		else if(num*4==g)
		//�����������û�ҵ��˸÷�����һ�ν����y���꣬���� 
		{
			return 1;
		}
	} 	
} 
int left3(int x1,int y1,int x2,int y2,int x3,int y3,int x4,int y4)
{
	
	if(xlite==10)
	{
		return 0;			
	}
	int g;
	for(g=0;g<=num*4;g++)
	{
	    if(list[g][0]==x3-20&&list[g][1]==y3&&list[g][3]==1)
		//������������ҵ��˸÷�����һ�ν����y���� 
		{ 
			return 0;							
		}
		else if(num*4==g)
		//�����������û�ҵ��˸÷�����һ�ν����y���꣬���� 
		{
			return 1;
		}
	} 	
} 
int left4(int x1,int y1,int x2,int y2,int x3,int y3,int x4,int y4)
{
	if(xlite==10)
	{
		return 0;			
	}
	int g;
	for(g=0;g<=num*4;g++)
	{
	    if(list[g][0]==x4-20&&list[g][1]==y4&&list[g][3]==1)
		//������������ҵ��˸÷�����һ�ν����y���� 
		{ 
			return 0;							
		}
		else if(num*4==g)
		//�����������û�ҵ��˸÷�����һ�ν����y���꣬���� 
		{
			return 1;
		}
	} 	
} 

//4���������ж� 
int right1(int x1,int y1,int x2,int y2,int x3,int y3,int x4,int y4)
{
	//ȡ�ĸ�x�����е����ֵ 
	xbest=(x1>=x2)?x1:x2;
	xbest=(xbest>=x3)?xbest:x3;
	xbest=(xbest>=x4)?xbest:x4;
	if(xbest==290)
	{
		return 0;			
	}
	int g;
	for(g=0;g<=num*4;g++)
	{
	    if(list[g][0]==x1+20&&list[g][1]==y1&&list[g][3]==1)
		//������������ҵ��˸÷�����һ�ν����y���� 
		{ 
			return 0;							
		}
		else if(num*4==g)
		//�����������û�ҵ��˸÷�����һ�ν����y���꣬���� 
		{
			return 1;
		}
	} 		
} 
int right2(int x1,int y1,int x2,int y2,int x3,int y3,int x4,int y4)
{
	if(xbest==290)
	{
		return 0;			
	}
	int g;
	for(g=0;g<=num*4;g++)
	{
	    if(list[g][0]==x2+20&&list[g][1]==y2&&list[g][3]==1)
		//������������ҵ��˸÷�����һ�ν����y���� 
		{ 
			return 0;							
		}
		else if(num*4==g)
		//�����������û�ҵ��˸÷�����һ�ν����y���꣬���� 
		{
			return 1;
		}
	} 	
} 
int right3(int x1,int y1,int x2,int y2,int x3,int y3,int x4,int y4)
{
	if(xbest==290)
	{
		return 0;			
	}
	int g;
	for(g=0;g<=num*4;g++)
	{
	    if(list[g][0]==x3+20&&list[g][1]==y3&&list[g][3]==1)
		//������������ҵ��˸÷�����һ�ν����y���� 
		{ 
			return 0;							
		}
		else if(num*4==g)
		//�����������û�ҵ��˸÷�����һ�ν����y���꣬���� 
		{
			return 1;
		}
	} 
} 
int right4(int x1,int y1,int x2,int y2,int x3,int y3,int x4,int y4)
{
	if(xbest==290)
	{
		return 0;			
	}
	int g;
	for(g=0;g<=num*4;g++)
	{
	    if(list[g][0]==x4+20&&list[g][1]==y4&&list[g][3]==1)
		//������������ҵ��˸÷�����һ�ν����y���� 
		{ 
			return 0;							
		}
		else if(num*4==g)
		//�����������û�ҵ��˸÷�����һ�ν����y���꣬���� 
		{
			return 1;
		}
	} 
} 

//�ж���ײ�������� --�����һ������ǰˢ�µ����� 
int down(int *x1,int *y1,int *x2,int *y2,int *x3,int *y3,int *x4,int *y4)//ͼ���ж�������ײ 
{
	int d1=0,d2=0,d3=0,d4=0;
	d1=down1(*x1,*y1,*x2,*y2,*x3,*y3,*x4,*y4);
	d2=down2(*x1,*y1,*x2,*y2,*x3,*y3,*x4,*y4);
	d3=down3(*x1,*y1,*x2,*y2,*x3,*y3,*x4,*y4);
	d4=down4(*x1,*y1,*x2,*y2,*x3,*y3,*x4,*y4);
	if(d1==1&&d2==1&&d3==1&&d4==1) return 1;
	else return 0;	
}

int left(int *x1,int *y1,int *x2,int *y2,int *x3,int *y3,int *x4,int *y4)//ͼ���ж�������ײ
{
	int l1=0,l2=0,l3=0,l4=0;
	l1=left1(*x1,*y1,*x2,*y2,*x3,*y3,*x4,*y4);
	l2=left2(*x1,*y1,*x2,*y2,*x3,*y3,*x4,*y4);
	l3=left3(*x1,*y1,*x2,*y2,*x3,*y3,*x4,*y4);
	l4=left4(*x1,*y1,*x2,*y2,*x3,*y3,*x4,*y4);
	if(l1==1&&l2==1&&l3==1&&l4==1) return 1;
	else return 0;
}

int right(int *x1,int *y1,int *x2,int *y2,int *x3,int *y3,int *x4,int *y4)//ͼ���ж�������ײ
{
	int r1=0,r2=0,r3=0,r4=0;
	r1=right1(*x1,*y1,*x2,*y2,*x3,*y3,*x4,*y4);
	r2=right2(*x1,*y1,*x2,*y2,*x3,*y3,*x4,*y4);
	r3=right3(*x1,*y1,*x2,*y2,*x3,*y3,*x4,*y4);
	r4=right4(*x1,*y1,*x2,*y2,*x3,*y3,*x4,*y4);
	if(r1==1&&r2==1&&r3==1&&r4==1) return 1;
	else return 0;	
}


//���ѡ��ͼ�κ������ͺ���---��ģ�������Խ����� 
void pickdown(int current)//�½� 
{
//	printf("y10=%d,y30=%d,y50=%d,y70=%d,y90=%d,y110=%d,y130=%d,y150=%d,y170=%d,y190=%d,y210=%d,y230=%d,y250=%d,y270=%d,y290=%d,y310=%d,y330=%d,y350=%d,y370=%d,y390=%d\n",y10,y30,y50,y70,y90,y110,y130,y150,y170,y190,y210,y230,y250,y270,y290,y310,y330,y350,y370,y390);
	if(current==0)
	{
		if(a==1)
		{
			if(a1tf==true)
			{
				lina1(a4[0][0],a4[0][1]);
				a1tf=false;					
			}
			dbool=down(&a1[0][0],&a1[0][1],&a1[1][0],&a1[1][1],&a1[2][0],&a1[2][1],&a1[3][0],&a1[3][1]);
			if(dbool==1)
			{ 
				a1[0][1]+=speed;
				a1[1][1]+=speed;
				a1[2][1]+=speed;
				a1[3][1]+=speed;
				optiona1();
			}	
			else if(dbool==0)
			{
				list[(num+1)*4-4][0]=a1[0][0];
				list[(num+1)*4-4][1]=a1[0][1];
				list[(num+1)*4-4][2]=1;
				list[(num+1)*4-4][3]=1;
				list[(num+1)*4-3][0]=a1[1][0];
				list[(num+1)*4-3][1]=a1[1][1];
				list[(num+1)*4-3][2]=1;
				list[(num+1)*4-3][3]=1;
				list[(num+1)*4-2][0]=a1[2][0];
				list[(num+1)*4-2][1]=a1[2][1];
				list[(num+1)*4-2][2]=1;
				list[(num+1)*4-2][3]=1;
				list[(num+1)*4-1][0]=a1[3][0];
				list[(num+1)*4-1][1]=a1[3][1];
				list[(num+1)*4-1][2]=1;
				list[(num+1)*4-1][3]=1;
				sqmumber ();
				num++;
				minor();
				recovery();			
				random();
				initac();
				initialization(x,y);
			}		
		}
		
		else if(a==2)
		{
		
			if(a2tf==false)
			{
				lina2(a1[0][0],a1[0][1]);
				a2tf=true;
			}
			
			dbool=down(&a2[0][0],&a2[0][1],&a2[1][0],&a2[1][1],&a2[2][0],&a2[2][1],&a2[3][0],&a2[3][1]);
			if(dbool==1)
			{
				a2[0][1]+=speed;
				a2[1][1]+=speed;
				a2[2][1]+=speed;
				a2[3][1]+=speed;
				optiona2();
			}	
			else if(dbool==0)
			{
				list[(num+1)*4-4][0]=a2[0][0];
				list[(num+1)*4-4][1]=a2[0][1];
				list[(num+1)*4-4][2]=1;
				list[(num+1)*4-4][3]=1;
				list[(num+1)*4-3][0]=a2[1][0];
				list[(num+1)*4-3][1]=a2[1][1];
				list[(num+1)*4-3][2]=1;
				list[(num+1)*4-3][3]=1;
				list[(num+1)*4-2][0]=a2[2][0];
				list[(num+1)*4-2][1]=a2[2][1];
				list[(num+1)*4-2][2]=1;
				list[(num+1)*4-2][3]=1;
				list[(num+1)*4-1][0]=a2[3][0];
				list[(num+1)*4-1][1]=a2[3][1];
				list[(num+1)*4-1][2]=1;
				list[(num+1)*4-1][3]=1;
				sqmumber ();
				num++;
				minor();
				recovery();			
				random();
				initac();
				initialization(x,y);
			}		
		}		
	
		else if(a==3)
		{
			if(a3tf==false){
				lina3(a2[0][0],a2[0][1]);
				a3tf=true;
			}			
			dbool=down(&a3[0][0],&a3[0][1],&a3[1][0],&a3[1][1],&a3[2][0],&a3[2][1],&a3[3][0],&a3[3][1]);
			if(dbool==1)
			{
				a3[0][1]+=speed;
				a3[1][1]+=speed;
				a3[2][1]+=speed;
				a3[3][1]+=speed;
				optiona3();
			}	
			else if(dbool==0)
			{
				list[(num+1)*4-4][0]=a3[0][0];
				list[(num+1)*4-4][1]=a3[0][1];
				list[(num+1)*4-4][2]=1;
				list[(num+1)*4-4][3]=1;
				list[(num+1)*4-3][0]=a3[1][0];
				list[(num+1)*4-3][1]=a3[1][1];
				list[(num+1)*4-3][2]=1;
				list[(num+1)*4-3][3]=1;
				list[(num+1)*4-2][0]=a3[2][0];
				list[(num+1)*4-2][1]=a3[2][1];
				list[(num+1)*4-2][2]=1;
				list[(num+1)*4-2][3]=1;
				list[(num+1)*4-1][0]=a3[3][0];
				list[(num+1)*4-1][1]=a3[3][1];
				list[(num+1)*4-1][2]=1;
				list[(num+1)*4-1][3]=1;
				sqmumber ();
				num++;
				minor();
				recovery();			
				random();
				initac();
				initialization(x,y);
			}		
		}
		
		else if(a==4)
		{
			if(a4tf==false){
				lina4(a3[0][0],a3[0][1]);
				a4tf=true;
			}
			dbool=down(&a4[0][0],&a4[0][1],&a4[1][0],&a4[1][1],&a4[2][0],&a4[2][1],&a4[3][0],&a4[3][1]);
			if(dbool==1)
			{
				a4[0][1]+=speed;
				a4[1][1]+=speed;
				a4[2][1]+=speed;
				a4[3][1]+=speed;
				optiona4();
			}	
			else if(dbool==0)
			{
				list[(num+1)*4-4][0]=a4[0][0];
				list[(num+1)*4-4][1]=a4[0][1];
				list[(num+1)*4-4][2]=1;
				list[(num+1)*4-4][3]=1;
				list[(num+1)*4-3][0]=a4[1][0];
				list[(num+1)*4-3][1]=a4[1][1];
				list[(num+1)*4-3][2]=1;
				list[(num+1)*4-3][3]=1;
				list[(num+1)*4-2][0]=a4[2][0];
				list[(num+1)*4-2][1]=a4[2][1];
				list[(num+1)*4-2][2]=1;
				list[(num+1)*4-2][3]=1;
				list[(num+1)*4-1][0]=a4[3][0];
				list[(num+1)*4-1][1]=a4[3][1];
				list[(num+1)*4-1][2]=1;
				list[(num+1)*4-1][3]=1;
				sqmumber ();
				num++;
				minor();
				recovery();			
				random();
				initac();
				initialization(x,y);
			}		
		}		
		
	}
	else if(current==1)
	{
		dbool=down(&b1[0][0],&b1[0][1],&b1[1][0],&b1[1][1],&b1[2][0],&b1[2][1],&b1[3][0],&b1[3][1]);
		if(dbool==1)
		{
			b1[0][1]+=speed;
			b1[1][1]+=speed;
			b1[2][1]+=speed;
			b1[3][1]+=speed;
			optionb1();
		}
		else if(dbool==0)
		{
			list[(num+1)*4-4][0]=b1[0][0];
			list[(num+1)*4-4][1]=b1[0][1];
			list[(num+1)*4-4][2]=2;
			list[(num+1)*4-4][3]=1;
			list[(num+1)*4-3][0]=b1[1][0];
			list[(num+1)*4-3][1]=b1[1][1];
			list[(num+1)*4-3][2]=2;
			list[(num+1)*4-3][3]=1;
			list[(num+1)*4-2][0]=b1[2][0];
			list[(num+1)*4-2][1]=b1[2][1];
			list[(num+1)*4-2][2]=2;
			list[(num+1)*4-2][3]=1;
			list[(num+1)*4-1][0]=b1[3][0];
			list[(num+1)*4-1][1]=b1[3][1];
			list[(num+1)*4-1][2]=2;
			list[(num+1)*4-1][3]=1;
			sqmumber ();
			num++;
			minor();
			recovery();	
			random();
			initialization(x,y);
		}		
	}
	else if(current==2)
	{
		if(c==1)
		{
			if(c1tf==true)
			{
				linc1(c4[0][0],c4[0][1]);
				c1tf=false;					
			}			
			dbool=down(&c1[0][0],&c1[0][1],&c1[1][0],&c1[1][1],&c1[2][0],&c1[2][1],&c1[3][0],&c1[3][1]);
			if(dbool==1)
			{
				c1[0][1]+=speed;
				c1[1][1]+=speed;
				c1[2][1]+=speed;
				c1[3][1]+=speed;
				optionc1();
			}
			else if(dbool==0)
			{
				list[(num+1)*4-4][0]=c1[0][0];
				list[(num+1)*4-4][1]=c1[0][1];
				list[(num+1)*4-4][2]=3;
				list[(num+1)*4-4][3]=1;
				list[(num+1)*4-3][0]=c1[1][0];
				list[(num+1)*4-3][1]=c1[1][1];
				list[(num+1)*4-3][2]=3;
				list[(num+1)*4-3][3]=1;
				list[(num+1)*4-2][0]=c1[2][0];
				list[(num+1)*4-2][1]=c1[2][1];
				list[(num+1)*4-2][2]=3;
				list[(num+1)*4-2][3]=1;
				list[(num+1)*4-1][0]=c1[3][0];
				list[(num+1)*4-1][1]=c1[3][1];
				list[(num+1)*4-1][2]=3;
				list[(num+1)*4-1][3]=1;
				sqmumber ();
				num++;
				minor();
				recovery();		
				random();
				initac();
				initialization(x,y);
			}					
		}

		else if(c==2)
		{
			if(c2tf==false)
			{
				linc2(c1[0][0],c1[0][1]);
				c2tf=true;					
			}			
			dbool=down(&c2[0][0],&c2[0][1],&c2[1][0],&c2[1][1],&c2[2][0],&c2[2][1],&c2[3][0],&c2[3][1]);
			if(dbool==1)
			{
				c2[0][1]+=speed;
				c2[1][1]+=speed;
				c2[2][1]+=speed;
				c2[3][1]+=speed;
				optionc2();
			}
			else if(dbool==0)
			{
				list[(num+1)*4-4][0]=c2[0][0];
				list[(num+1)*4-4][1]=c2[0][1];
				list[(num+1)*4-4][2]=3;
				list[(num+1)*4-4][3]=1;
				list[(num+1)*4-3][0]=c2[1][0];
				list[(num+1)*4-3][1]=c2[1][1];
				list[(num+1)*4-3][2]=3;
				list[(num+1)*4-3][3]=1;
				list[(num+1)*4-2][0]=c2[2][0];
				list[(num+1)*4-2][1]=c2[2][1];
				list[(num+1)*4-2][2]=3;
				list[(num+1)*4-2][3]=1;
				list[(num+1)*4-1][0]=c2[3][0];
				list[(num+1)*4-1][1]=c2[3][1];
				list[(num+1)*4-1][2]=3;
				list[(num+1)*4-1][3]=1;
				sqmumber ();
				num++;
				minor();
				recovery();		
				random();
				initac();
				initialization(x,y);
			}								
		}
		
		else if(c==3)
		{
			if(c3tf==false)
			{
				linc3(c2[0][0],c2[0][1]);
				c3tf=true;					
			}			
			dbool=down(&c3[0][0],&c3[0][1],&c3[1][0],&c3[1][1],&c3[2][0],&c3[2][1],&c3[3][0],&c3[3][1]);
			if(dbool==1)
			{
				c3[0][1]+=speed;
				c3[1][1]+=speed;
				c3[2][1]+=speed;
				c3[3][1]+=speed;
				optionc3();
			}
			else if(dbool==0)
			{
				list[(num+1)*4-4][0]=c3[0][0];
				list[(num+1)*4-4][1]=c3[0][1];
				list[(num+1)*4-4][2]=3;
				list[(num+1)*4-4][3]=1;
				list[(num+1)*4-3][0]=c3[1][0];
				list[(num+1)*4-3][1]=c3[1][1];
				list[(num+1)*4-3][2]=3;
				list[(num+1)*4-3][3]=1;
				list[(num+1)*4-2][0]=c3[2][0];
				list[(num+1)*4-2][1]=c3[2][1];
				list[(num+1)*4-2][2]=3;
				list[(num+1)*4-2][3]=1;
				list[(num+1)*4-1][0]=c3[3][0];
				list[(num+1)*4-1][1]=c3[3][1];
				list[(num+1)*4-1][2]=3;
				list[(num+1)*4-1][3]=1;
				sqmumber ();
				num++;
				minor();
				recovery();		
				random();
				initac();
				initialization(x,y);
			}			
		}
		
		else if(c==4)
		{
			if(c4tf==false)
			{
				linc4(c3[0][0],c3[0][1]);
				c4tf=true;					
			}			
			dbool=down(&c3[4][0],&c4[0][1],&c4[1][0],&c4[1][1],&c4[2][0],&c4[2][1],&c4[3][0],&c4[3][1]);
			if(dbool==1)
			{
				c4[0][1]+=speed;
				c4[1][1]+=speed;
				c4[2][1]+=speed;
				c4[3][1]+=speed;
				optionc4();
			}
			else if(dbool==0)
			{
				list[(num+1)*4-4][0]=c4[0][0];
				list[(num+1)*4-4][1]=c4[0][1];
				list[(num+1)*4-4][2]=3;
				list[(num+1)*4-4][3]=1;
				list[(num+1)*4-3][0]=c4[1][0];
				list[(num+1)*4-3][1]=c4[1][1];
				list[(num+1)*4-3][2]=3;
				list[(num+1)*4-3][3]=1;
				list[(num+1)*4-2][0]=c4[2][0];
				list[(num+1)*4-2][1]=c4[2][1];
				list[(num+1)*4-2][2]=3;
				list[(num+1)*4-2][3]=1;
				list[(num+1)*4-1][0]=c4[3][0];
				list[(num+1)*4-1][1]=c4[3][1];
				list[(num+1)*4-1][2]=3;
				list[(num+1)*4-1][3]=1;
				sqmumber ();
				num++;
				minor();
				recovery();		
				random();
				initac();
				initialization(x,y);
			}			
		}
		
	}	
	else if(current==3)
	{
		if(d==1)
		{
			if(d1tf==true)
			{
				lind1(d2[0][0],d2[0][1]);
				d1tf=false;					
			}
			dbool=down(&d1[0][0],&d1[0][1],&d1[1][0],&d1[1][1],&d1[2][0],&d1[2][1],&d1[3][0],&d1[3][1]);
			if(dbool==1)
			{
				d1[0][1]+=speed;
				d1[1][1]+=speed;
				d1[2][1]+=speed;
				d1[3][1]+=speed;
				optiond1();
			}
			else if(dbool==0)
			{
				list[(num+1)*4-4][0]=d1[0][0];
				list[(num+1)*4-4][1]=d1[0][1];
				list[(num+1)*4-4][2]=4;
				list[(num+1)*4-4][3]=1;
				list[(num+1)*4-3][0]=d1[1][0];
				list[(num+1)*4-3][1]=d1[1][1];
				list[(num+1)*4-3][2]=4;
				list[(num+1)*4-3][3]=1;
				list[(num+1)*4-2][0]=d1[2][0];
				list[(num+1)*4-2][1]=d1[2][1];
				list[(num+1)*4-2][2]=4;
				list[(num+1)*4-2][3]=1;
				list[(num+1)*4-1][0]=d1[3][0];
				list[(num+1)*4-1][1]=d1[3][1];
				list[(num+1)*4-1][2]=4;
				list[(num+1)*4-1][3]=1;
				sqmumber ();
				num++;
				minor();
				recovery();	
				random();
				initac();
				initialization(x,y);
			}				
		}
		else if(d==2)
		{
			if(d2tf==false)
			{
				lind2(d1[0][0],d1[0][1]);
				d2tf=true;					
			}
			dbool=down(&d2[0][0],&d2[0][1],&d2[1][0],&d2[1][1],&d2[2][0],&d2[2][1],&d2[3][0],&d2[3][1]);
			if(dbool==1)
			{
				d2[0][1]+=speed;
				d2[1][1]+=speed;
				d2[2][1]+=speed;
				d2[3][1]+=speed;
				optiond2();
			}
			else if(dbool==0)
			{
				list[(num+1)*4-4][0]=d2[0][0];
				list[(num+1)*4-4][1]=d2[0][1];
				list[(num+1)*4-4][2]=4;
				list[(num+1)*4-4][3]=1;
				list[(num+1)*4-3][0]=d2[1][0];
				list[(num+1)*4-3][1]=d2[1][1];
				list[(num+1)*4-3][2]=4;
				list[(num+1)*4-3][3]=1;
				list[(num+1)*4-2][0]=d2[2][0];
				list[(num+1)*4-2][1]=d2[2][1];
				list[(num+1)*4-2][2]=4;
				list[(num+1)*4-2][3]=1;
				list[(num+1)*4-1][0]=d2[3][0];
				list[(num+1)*4-1][1]=d2[3][1];
				list[(num+1)*4-1][2]=4;
				list[(num+1)*4-1][3]=1;
				sqmumber ();
				num++;
				minor();
				recovery();	
				random();
				initac();
				initialization(x,y);
			}			
		}		
	}	
	else if(current==4)
	{
		if(e==1)
		{
			if(e1tf==true)
			{
				line1(e2[0][0],e2[0][1]);
				e1tf=false;					
			}
			dbool=down(&e1[0][0],&e1[0][1],&e1[1][0],&e1[1][1],&e1[2][0],&e1[2][1],&e1[3][0],&e1[3][1]);
			if(dbool==1)
			{
				e1[0][1]+=speed;
				e1[1][1]+=speed;
				e1[2][1]+=speed;
				e1[3][1]+=speed;
				optione1();
			}
			else if(dbool==0)
			{
				list[(num+1)*4-4][0]=e1[0][0];
				list[(num+1)*4-4][1]=e1[0][1];
				list[(num+1)*4-4][2]=5;
				list[(num+1)*4-4][3]=1;
				list[(num+1)*4-3][0]=e1[1][0];
				list[(num+1)*4-3][1]=e1[1][1];
				list[(num+1)*4-3][2]=5;
				list[(num+1)*4-3][3]=1;
				list[(num+1)*4-2][0]=e1[2][0];
				list[(num+1)*4-2][1]=e1[2][1];
				list[(num+1)*4-2][2]=5;
				list[(num+1)*4-2][3]=1;
				list[(num+1)*4-1][0]=e1[3][0];
				list[(num+1)*4-1][1]=e1[3][1];
				list[(num+1)*4-1][2]=5;
				list[(num+1)*4-1][3]=1;
				sqmumber ();
				num++;
				minor();
				recovery();	
				random();
				initac();
				initialization(x,y);
			}						
		}

		else if(e==2)
		{
			if(e2tf==false)
			{
				line2(e1[0][0],e1[0][1]);
				e2tf=true;					
			}
			dbool=down(&e2[0][0],&e2[0][1],&e2[1][0],&e2[1][1],&e2[2][0],&e2[2][1],&e2[3][0],&e2[3][1]);
			if(dbool==1)
			{
				e2[0][1]+=speed;
				e2[1][1]+=speed;
				e2[2][1]+=speed;
				e2[3][1]+=speed;
				optione2();
			}
			else if(dbool==0)
			{
				list[(num+1)*4-4][0]=e2[0][0];
				list[(num+1)*4-4][1]=e2[0][1];
				list[(num+1)*4-4][2]=5;
				list[(num+1)*4-4][3]=1;
				list[(num+1)*4-3][0]=e2[1][0];
				list[(num+1)*4-3][1]=e2[1][1];
				list[(num+1)*4-3][2]=5;
				list[(num+1)*4-3][3]=1;
				list[(num+1)*4-2][0]=e2[2][0];
				list[(num+1)*4-2][1]=e2[2][1];
				list[(num+1)*4-2][2]=5;
				list[(num+1)*4-2][3]=1;
				list[(num+1)*4-1][0]=e2[3][0];
				list[(num+1)*4-1][1]=e2[3][1];
				list[(num+1)*4-1][2]=5;
				list[(num+1)*4-1][3]=1;
				sqmumber ();
				num++;
				minor();
				recovery();	
				random();
				initac();
				initialization(x,y);
			}
		}
	}	
	else if(current==5)
	{
		if(f==1)
		{
			if(f1tf==true)
			{
				linf1(f2[0][0],f2[0][1]);
				f1tf=false;					
			}
			dbool=down(&f1[0][0],&f1[0][1],&f1[1][0],&f1[1][1],&f1[2][0],&f1[2][1],&f1[3][0],&f1[3][1]);
			if(dbool==1)
			{
				f1[0][1]+=speed;
				f1[1][1]+=speed;
				f1[2][1]+=speed;
				f1[3][1]+=speed;
				optionf1();
			}
			else if(dbool==0)
			{	
				list[(num+1)*4-4][0]=f1[0][0];
				list[(num+1)*4-4][1]=f1[0][1];
				list[(num+1)*4-4][2]=6;
				list[(num+1)*4-4][3]=1;
				list[(num+1)*4-3][0]=f1[1][0];
				list[(num+1)*4-3][1]=f1[1][1];
				list[(num+1)*4-3][2]=6;
				list[(num+1)*4-3][3]=1;
				list[(num+1)*4-2][0]=f1[2][0];
				list[(num+1)*4-2][1]=f1[2][1];
				list[(num+1)*4-2][2]=6;
				list[(num+1)*4-2][3]=1;
				list[(num+1)*4-1][0]=f1[3][0];
				list[(num+1)*4-1][1]=f1[3][1];
				list[(num+1)*4-1][2]=6;
				list[(num+1)*4-1][3]=1;
				sqmumber ();
				num++;
				minor();
				recovery();	
				random();
				initac();
				initialization(x,y);
			}			
						
		}
		
		else if(f==2)
		{
			if(f2tf==false)
			{
				linf2(f1[0][0],f1[0][1]);
				f2tf=true;					
			}
			dbool=down(&f2[0][0],&f2[0][1],&f2[1][0],&f2[1][1],&f2[2][0],&f2[2][1],&f2[3][0],&f2[3][1]);
			if(dbool==1)
			{
				f2[0][1]+=speed;
				f2[1][1]+=speed;
				f2[2][1]+=speed;
				f2[3][1]+=speed;
				optionf2();
			}
			else if(dbool==0)
			{	
				list[(num+1)*4-4][0]=f2[0][0];
				list[(num+1)*4-4][1]=f2[0][1];
				list[(num+1)*4-4][2]=6;
				list[(num+1)*4-4][3]=1;
				list[(num+1)*4-3][0]=f2[1][0];
				list[(num+1)*4-3][1]=f2[1][1];
				list[(num+1)*4-3][2]=6;
				list[(num+1)*4-3][3]=1;
				list[(num+1)*4-2][0]=f2[2][0];
				list[(num+1)*4-2][1]=f2[2][1];
				list[(num+1)*4-2][2]=6;
				list[(num+1)*4-2][3]=1;
				list[(num+1)*4-1][0]=f2[3][0];
				list[(num+1)*4-1][1]=f2[3][1];
				list[(num+1)*4-1][2]=6;
				list[(num+1)*4-1][3]=1;
				sqmumber ();
				num++;
				minor();
				recovery();	
				random();
				initac();
				initialization(x,y);
			}			
		}

	}	
	else if(current==6)
	{
		if(g==1)
		{
			if(g1tf==true)
			{
				ling1(g4[0][0],g4[0][1]);
				g1tf=false;					
			}
			dbool=down(&g1[0][0],&g1[0][1],&g1[1][0],&g1[1][1],&g1[2][0],&g1[2][1],&g1[3][0],&g1[3][1]);
			if(dbool==1)
			{
				g1[0][1]+=speed;
				g1[1][1]+=speed;
				g1[2][1]+=speed;
				g1[3][1]+=speed;
				optiong1();
			}
			else if(dbool==0)
			{
	
				list[(num+1)*4-4][0]=g1[0][0];
				list[(num+1)*4-4][1]=g1[0][1];
				list[(num+1)*4-4][2]=7;
				list[(num+1)*4-4][3]=1;
				list[(num+1)*4-3][0]=g1[1][0];
				list[(num+1)*4-3][1]=g1[1][1];
				list[(num+1)*4-3][2]=7;
				list[(num+1)*4-3][3]=1;
				list[(num+1)*4-2][0]=g1[2][0];
				list[(num+1)*4-2][1]=g1[2][1];
				list[(num+1)*4-2][2]=7;
				list[(num+1)*4-2][3]=1;
				list[(num+1)*4-1][0]=g1[3][0];
				list[(num+1)*4-1][1]=g1[3][1];
				list[(num+1)*4-1][2]=7;
				list[(num+1)*4-1][3]=1;
				sqmumber ();
				num++;
				minor();
				recovery();	
				random();
				initac();
				initialization(x,y);
			}
						
		}
		else if(g==2)
		{
			if(g2tf==false)
			{
				ling2(g1[0][0],g1[0][1]);
				g2tf=true;					
			}
			dbool=down(&g2[0][0],&g2[0][1],&g2[1][0],&g2[1][1],&g2[2][0],&g2[2][1],&g2[3][0],&g2[3][1]);
			if(dbool==1)
			{
				g2[0][1]+=speed;
				g2[1][1]+=speed;
				g2[2][1]+=speed;
				g2[3][1]+=speed;
				optiong2();
			}
			else if(dbool==0)
			{
	
				list[(num+1)*4-4][0]=g2[0][0];
				list[(num+1)*4-4][1]=g2[0][1];
				list[(num+1)*4-4][2]=7;
				list[(num+1)*4-4][3]=1;
				list[(num+1)*4-3][0]=g2[1][0];
				list[(num+1)*4-3][1]=g2[1][1];
				list[(num+1)*4-3][2]=7;
				list[(num+1)*4-3][3]=1;
				list[(num+1)*4-2][0]=g2[2][0];
				list[(num+1)*4-2][1]=g2[2][1];
				list[(num+1)*4-2][2]=7;
				list[(num+1)*4-2][3]=1;
				list[(num+1)*4-1][0]=g2[3][0];
				list[(num+1)*4-1][1]=g2[3][1];
				list[(num+1)*4-1][2]=7;
				list[(num+1)*4-1][3]=1;
				sqmumber ();
				num++;
				minor();
				recovery();	
				random();
				initac();
				initialization(x,y);
			}			
		}
		else if(g==3)
		{
			if(g3tf==false)
			{
				ling3(g2[0][0],g2[0][1]);
				g3tf=true;					
			}
			dbool=down(&g3[0][0],&g3[0][1],&g3[1][0],&g3[1][1],&g3[2][0],&g3[2][1],&g3[3][0],&g3[3][1]);
			if(dbool==1)
			{
				g3[0][1]+=speed;
				g3[1][1]+=speed;
				g3[2][1]+=speed;
				g3[3][1]+=speed;
				optiong3();
			}
			else if(dbool==0)
			{
	
				list[(num+1)*4-4][0]=g3[0][0];
				list[(num+1)*4-4][1]=g3[0][1];
				list[(num+1)*4-4][2]=7;
				list[(num+1)*4-4][3]=1;
				list[(num+1)*4-3][0]=g3[1][0];
				list[(num+1)*4-3][1]=g3[1][1];
				list[(num+1)*4-3][2]=7;
				list[(num+1)*4-3][3]=1;
				list[(num+1)*4-2][0]=g3[2][0];
				list[(num+1)*4-2][1]=g3[2][1];
				list[(num+1)*4-2][2]=7;
				list[(num+1)*4-2][3]=1;
				list[(num+1)*4-1][0]=g3[3][0];
				list[(num+1)*4-1][1]=g3[3][1];
				list[(num+1)*4-1][2]=7;
				list[(num+1)*4-1][3]=1;
				sqmumber ();
				num++;
				minor();
				recovery();	
				random();
				initac();
				initialization(x,y);
			}			
		}
		else if(g==4)
		{
			if(g4tf==false)
			{
				ling4(g3[0][0],g3[0][1]);
				g4tf=true;					
			}
			dbool=down(&g4[0][0],&g4[0][1],&g4[1][0],&g4[1][1],&g4[2][0],&g4[2][1],&g4[3][0],&g4[3][1]);
			if(dbool==1)
			{
				g4[0][1]+=speed;
				g4[1][1]+=speed;
				g4[2][1]+=speed;
				g4[3][1]+=speed;
				optiong4();
			}
			else if(dbool==0)
			{
	
				list[(num+1)*4-4][0]=g4[0][0];
				list[(num+1)*4-4][1]=g4[0][1];
				list[(num+1)*4-4][2]=7;
				list[(num+1)*4-4][3]=1;
				list[(num+1)*4-3][0]=g4[1][0];
				list[(num+1)*4-3][1]=g4[1][1];
				list[(num+1)*4-3][2]=7;
				list[(num+1)*4-3][3]=1;
				list[(num+1)*4-2][0]=g4[2][0];
				list[(num+1)*4-2][1]=g4[2][1];
				list[(num+1)*4-2][2]=7;
				list[(num+1)*4-2][3]=1;
				list[(num+1)*4-1][0]=g4[3][0];
				list[(num+1)*4-1][1]=g4[3][1];
				list[(num+1)*4-1][2]=7;
				list[(num+1)*4-1][3]=1;
				sqmumber ();
				num++;
				minor();
				recovery();	
				random();
				initac();
				initialization(x,y);
			}			
		}		
	}	
}

void pickleft()//���� 
{
	if(current==0)	
	{
		if(a==1)
		{
			lbool=left(&a1[0][0],&a1[0][1],&a1[1][0],&a1[1][1],&a1[2][0],&a1[2][1],&a1[3][0],&a1[3][1]);
			if(lbool==1)
			{
				a1[0][0]-=speed;
				a1[1][0]-=speed;
				a1[2][0]-=speed;
				a1[3][0]-=speed;
				optiona1();
			}			
	 	} 
		
		else if(a==2)
		{
			lbool=left(&a2[0][0],&a2[0][1],&a2[1][0],&a2[1][1],&a2[2][0],&a2[2][1],&a2[3][0],&a2[3][1]);
			if(lbool==1)
			{
				a2[0][0]-=speed;
				a2[1][0]-=speed;
				a2[2][0]-=speed;
				a2[3][0]-=speed;
				optiona2();
			}					
		}
		
		else if(a==3)
		{
			lbool=left(&a3[0][0],&a3[0][1],&a3[1][0],&a3[1][1],&a3[2][0],&a3[2][1],&a3[3][0],&a3[3][1]);
			if(lbool==1)
			{
				a3[0][0]-=speed;
				a3[1][0]-=speed;
				a3[2][0]-=speed;
				a3[3][0]-=speed;
				optiona3();
			}					
		}
		
		else if(a==4)
		{
			lbool=left(&a4[0][0],&a4[0][1],&a4[1][0],&a4[1][1],&a4[2][0],&a4[2][1],&a4[3][0],&a4[3][1]);
			if(lbool==1)
			{
				a4[0][0]-=speed;
				a4[1][0]-=speed;
				a4[2][0]-=speed;
				a4[3][0]-=speed;
				optiona4();
			}					
		}

	}
	else if(current==1)
	{
		lbool=left(&b1[0][0],&b1[0][1],&b1[1][0],&b1[1][1],&b1[2][0],&b1[2][1],&b1[3][0],&b1[3][1]);
		if(lbool==1)
		{
			b1[0][0]-=speed;
			b1[1][0]-=speed;
			b1[2][0]-=speed;
			b1[3][0]-=speed;
			optionb1();
		}	
	}
	else if(current==2)
	{
		if(c==1)
		{
			lbool=left(&c1[0][0],&c1[0][1],&c1[1][0],&c1[1][1],&c1[2][0],&c1[2][1],&c1[3][0],&c1[3][1]);
			if(lbool==1)
			{
				c1[0][0]-=speed;
				c1[1][0]-=speed;
				c1[2][0]-=speed;
				c1[3][0]-=speed;
				optionc1();
			}		
		}
		
		else if(c==2)
		{
			lbool=left(&c2[0][0],&c2[0][1],&c2[1][0],&c2[1][1],&c2[2][0],&c2[2][1],&c2[3][0],&c2[3][1]);
			if(lbool==1)
			{
				c2[0][0]-=speed;
				c2[1][0]-=speed;
				c2[2][0]-=speed;
				c2[3][0]-=speed;
				optionc2();
			}			
		}
		
		else if(c==3)
		{
			lbool=left(&c3[0][0],&c3[0][1],&c3[1][0],&c3[1][1],&c3[2][0],&c3[2][1],&c3[3][0],&c3[3][1]);
			if(lbool==1)
			{
				c3[0][0]-=speed;
				c3[1][0]-=speed;
				c3[2][0]-=speed;
				c3[3][0]-=speed;
				optionc3();
			}
		}
		
		else if(c==4)
		{
			lbool=left(&c4[0][0],&c4[0][1],&c4[1][0],&c4[1][1],&c4[2][0],&c4[2][1],&c4[3][0],&c4[3][1]);
			if(lbool==1)
			{
				c4[0][0]-=speed;
				c4[1][0]-=speed;
				c4[2][0]-=speed;
				c4[3][0]-=speed;
				optionc4();			
			}
		}
	}	
	else if(current==3)
	{
		if(d==1)
		{
			lbool=left(&d1[0][0],&d1[0][1],&d1[1][0],&d1[1][1],&d1[2][0],&d1[2][1],&d1[3][0],&d1[3][1]);
			if(lbool==1)
			{
				d1[0][0]-=speed;
				d1[1][0]-=speed;
				d1[2][0]-=speed;
				d1[3][0]-=speed;
				optiond1();
			}		
		}
		else if(d==2)
		{
			lbool=left(&d2[0][0],&d2[0][1],&d2[1][0],&d2[1][1],&d2[2][0],&d2[2][1],&d2[3][0],&d2[3][1]);
			if(lbool==1)
			{
				d2[0][0]-=speed;
				d2[1][0]-=speed;
				d2[2][0]-=speed;
				d2[3][0]-=speed;
				optiond2();
			}			
		}
	
	}	
	else if(current==4)
	{
		if(e==1)
		{
			lbool=left(&e1[0][0],&e1[0][1],&e1[1][0],&e1[1][1],&e1[2][0],&e1[2][1],&e1[3][0],&e1[3][1]);
			if(lbool==1)
			{
				e1[0][0]-=speed;
				e1[1][0]-=speed;
				e1[2][0]-=speed;
				e1[3][0]-=speed;
				optione1();
			}			
		} 
		
		else if(e==2)
		{
			lbool=left(&e2[0][0],&e2[0][1],&e2[1][0],&e2[1][1],&e2[2][0],&e2[2][1],&e2[3][0],&e2[3][1]);
			if(lbool==1)
			{
				e2[0][0]-=speed;
				e2[1][0]-=speed;
				e2[2][0]-=speed;
				e2[3][0]-=speed;
				optione2();			
			}
		}
	}	
	else if(current==5)
	{
		if(f==1)
		{
			lbool=left(&f1[0][0],&f1[0][1],&f1[1][0],&f1[1][1],&f1[2][0],&f1[2][1],&f1[3][0],&f1[3][1]);
			if(lbool==1)
			{
				f1[0][0]-=speed;
				f1[1][0]-=speed;
				f1[2][0]-=speed;
				f1[3][0]-=speed;
				optionf1();
			}			
		}
		
		else if(f==2)
		{
			lbool=left(&f2[0][0],&f2[0][1],&f2[1][0],&f2[1][1],&f2[2][0],&f2[2][1],&f2[3][0],&f2[3][1]);
			if(lbool==1)
			{
				f2[0][0]-=speed;
				f2[1][0]-=speed;
				f2[2][0]-=speed;
				f2[3][0]-=speed;
				optionf2();
			}			
		}
		
			
	}	
	else if(current==6)
	{
		if(g==1)
		{
			lbool=left(&g1[0][0],&g1[0][1],&g1[1][0],&g1[1][1],&g1[2][0],&g1[2][1],&g1[3][0],&g1[3][1]);
			if(lbool==1)
			{
				g1[0][0]-=speed;
				g1[1][0]-=speed;
				g1[2][0]-=speed;
				g1[3][0]-=speed;
				optiong1();
			}			
		}
		
		else if(g==2)
		{
			lbool=left(&g2[0][0],&g2[0][1],&g2[1][0],&g2[1][1],&g2[2][0],&g2[2][1],&g2[3][0],&g2[3][1]);
			if(lbool==1)
			{
				g2[0][0]-=speed;
				g2[1][0]-=speed;
				g2[2][0]-=speed;
				g2[3][0]-=speed;
				optiong2();
			}						
		}
		
		else if(g==3)
		{
			lbool=left(&g3[0][0],&g3[0][1],&g3[1][0],&g3[1][1],&g3[2][0],&g3[2][1],&g3[3][0],&g3[3][1]);
			if(lbool==1)
			{
				g3[0][0]-=speed;
				g3[1][0]-=speed;
				g3[2][0]-=speed;
				g3[3][0]-=speed;
				optiong3();	
			}
		}
		
		else if(g==4)
		{
			lbool=left(&g4[0][0],&g4[0][1],&g4[1][0],&g4[1][1],&g4[2][0],&g4[2][1],&g4[3][0],&g4[3][1]);
			if(lbool==1)
			{
				g4[0][0]-=speed;
				g4[1][0]-=speed;
				g4[2][0]-=speed;
				g4[3][0]-=speed;
				optiong4();			
			}			
		}
	}
}

void pickright()//����
{
	if(current==0)	
	{
		if(a==1)
		{
			rbool=right(&a1[0][0],&a1[0][1],&a1[1][0],&a1[1][1],&a1[2][0],&a1[2][1],&a1[3][0],&a1[3][1]);
			if(rbool==1)
			{
				a1[0][0]+=speed;
				a1[1][0]+=speed;
				a1[2][0]+=speed;
				a1[3][0]+=speed;
				optiona1();
			}			
		}
		
		else if(a==2)
		{
			rbool=right(&a2[0][0],&a2[0][1],&a2[1][0],&a2[1][1],&a2[2][0],&a2[2][1],&a2[3][0],&a2[3][1]);
			if(rbool==1)
			{
				a2[0][0]+=speed;
				a2[1][0]+=speed;
				a2[2][0]+=speed;
				a2[3][0]+=speed;
				optiona2();
			}			
		}
		
		else if(a==3)
		{
			rbool=right(&a3[0][0],&a3[0][1],&a3[1][0],&a3[1][1],&a3[2][0],&a3[2][1],&a3[3][0],&a3[3][1]);
			if(rbool==1)
			{
				a3[0][0]+=speed;
				a3[1][0]+=speed;
				a3[2][0]+=speed;
				a3[3][0]+=speed;
				optiona3();
			}			
		}
		
		else if(a==4)
		{
			rbool=right(&a4[0][0],&a4[0][1],&a4[1][0],&a4[1][1],&a4[2][0],&a4[2][1],&a4[3][0],&a4[3][1]);
			if(rbool==1)
			{
				a4[0][0]+=speed;
				a4[1][0]+=speed;
				a4[2][0]+=speed;
				a4[3][0]+=speed;
				optiona4();
			}			
		}

	}
	else if(current==1)
	{
		rbool=right(&b1[0][0],&b1[0][1],&b1[1][0],&b1[1][1],&b1[2][0],&b1[2][1],&b1[3][0],&b1[3][1]);
		if(rbool==1)
		{
			b1[0][0]+=speed;
			b1[1][0]+=speed;
			b1[2][0]+=speed;
			b1[3][0]+=speed;
			optionb1();
		}	
	}
	else if(current==2)
	{
		if(c==1)
		{
			rbool=right(&c1[0][0],&c1[0][1],&c1[1][0],&c1[1][1],&c1[2][0],&c1[2][1],&c1[3][0],&c1[3][1]);
			if(rbool==1)
			{
				c1[0][0]+=speed;
				c1[1][0]+=speed;
				c1[2][0]+=speed;
				c1[3][0]+=speed;
				optionc1();
		}			
		}
		
		else if(c==2)
		{
			rbool=right(&c2[0][0],&c2[0][1],&c2[1][0],&c2[1][1],&c2[2][0],&c2[2][1],&c2[3][0],&c2[3][1]);
			if(rbool==1)
			{
				c2[0][0]+=speed;
				c2[1][0]+=speed;
				c2[2][0]+=speed;
				c2[3][0]+=speed;
				optionc2();	
			}
		}
		
		else if(c==3)
		{
			rbool=right(&c3[0][0],&c3[0][1],&c3[1][0],&c3[1][1],&c3[2][0],&c3[2][1],&c3[3][0],&c3[3][1]);
			if(rbool==1)
			{
				c3[0][0]+=speed;
				c3[1][0]+=speed;
				c3[2][0]+=speed;
				c3[3][0]+=speed;
				optionc3();	
			}			
		}
		
		else if(c==4)
		{
			rbool=right(&c4[0][0],&c4[0][1],&c4[1][0],&c4[1][1],&c4[2][0],&c4[2][1],&c4[3][0],&c4[3][1]);
			if(rbool==1)
			{
				c4[0][0]+=speed;
				c4[1][0]+=speed;
				c4[2][0]+=speed;
				c4[3][0]+=speed;
				optionc4();	
			}			
		}
	
	}	
	else if(current==3)
	{
		if(d==1)
		{
			rbool=right(&d1[0][0],&d1[0][1],&d1[1][0],&d1[1][1],&d1[2][0],&d1[2][1],&d1[3][0],&d1[3][1]);
			if(rbool==1)
			{
				d1[0][0]+=speed;
				d1[1][0]+=speed;
				d1[2][0]+=speed;
				d1[3][0]+=speed;
				optiond1();
			}				
		}
		
		else if(d==2)
		{
			rbool=right(&d2[0][0],&d2[0][1],&d2[1][0],&d2[1][1],&d2[2][0],&d2[2][1],&d2[3][0],&d2[3][1]);
			if(rbool==1)
			{
				d2[0][0]+=speed;
				d2[1][0]+=speed;
				d2[2][0]+=speed;
				d2[3][0]+=speed;
				optiond2();
			}				
		}

	}	
	else if(current==4)
	{
		if(e==1)
		{
			rbool=right(&e1[0][0],&e1[0][1],&e1[1][0],&e1[1][1],&e1[2][0],&e1[2][1],&e1[3][0],&e1[3][1]);
			if(rbool==1)
			{
				e1[0][0]+=speed;
				e1[1][0]+=speed;
				e1[2][0]+=speed;
				e1[3][0]+=speed;
				optione1();
			}				
		}
		
		else if(e==2)
		{
			rbool=right(&e2[0][0],&e2[0][1],&e2[1][0],&e2[1][1],&e2[2][0],&e2[2][1],&e2[3][0],&e2[3][1]);
			if(rbool==1)
			{
				e2[0][0]+=speed;
				e2[1][0]+=speed;
				e2[2][0]+=speed;
				e2[3][0]+=speed;
				optione2();
			}			
		}
	
	}	
	else if(current==5)
	{
		if(f==1)
		{
			rbool=right(&f1[0][0],&f1[0][1],&f1[1][0],&f1[1][1],&f1[2][0],&f1[2][1],&f1[3][0],&f1[3][1]);
			if(rbool==1)
			{
				f1[0][0]+=speed;
				f1[1][0]+=speed;
				f1[2][0]+=speed;
				f1[3][0]+=speed;
				optionf1();	
			}
		}
		
		else if(f==2)
		{
			rbool=right(&f2[0][0],&f2[0][1],&f2[1][0],&f2[1][1],&f2[2][0],&f2[2][1],&f2[3][0],&f2[3][1]);
			if(rbool==1)
			{
				f2[0][0]+=speed;
				f2[1][0]+=speed;
				f2[2][0]+=speed;
				f2[3][0]+=speed;
				optionf2();				
			}
		}			
	}	
	else if(current==6)
	{
		if(g==1)
		{
			rbool=right(&g1[0][0],&g1[0][1],&g1[1][0],&g1[1][1],&g1[2][0],&g1[2][1],&g1[3][0],&g1[3][1]);
			if(rbool==1)
			{
				g1[0][0]+=speed;
				g1[1][0]+=speed;
				g1[2][0]+=speed;
				g1[3][0]+=speed;
				optiong1();
			}			
		}
		
		else if(g==2)
		{
			rbool=right(&g2[0][0],&g2[0][1],&g2[1][0],&g2[1][1],&g2[2][0],&g2[2][1],&g2[3][0],&g2[3][1]);
			if(rbool==1)
			{
				g2[0][0]+=speed;
				g2[1][0]+=speed;
				g2[2][0]+=speed;
				g2[3][0]+=speed;
				optiong2();	
			}
		}
		
		else if(g==3)
		{
			rbool=right(&g3[0][0],&g3[0][1],&g3[1][0],&g3[1][1],&g3[2][0],&g3[2][1],&g3[3][0],&g3[3][1]);
			if(rbool==1)
			{
				g3[0][0]+=speed;
				g3[1][0]+=speed;
				g3[2][0]+=speed;
				g3[3][0]+=speed;
				optiong3();	
			}			
		}
		
		else if(g==4)
		{
			rbool=right(&g4[0][0],&g4[0][1],&g4[1][0],&g4[1][1],&g4[2][0],&g4[2][1],&g4[3][0],&g4[3][1]);
			if(rbool==1)
			{
				g4[0][0]+=speed;
				g4[1][0]+=speed;
				g4[2][0]+=speed;
				g4[3][0]+=speed;
				optiong4();	
			}			
		}			
	}
}

void over()//���� 
{
	int g;
	for(g=0;g<num*4;g++)
	{
		if(list[g][1]==10)
		{
			gameover();
			cancelTimer(0);
		}
	}
} 

void downmain()
{
	over();
	minor();
	recovery();		
	pickdown(current);
	nextimg(xi,yi);
	over(); 
}

/*------------------------�ص�����--------------------------*/ 
void speedModi( int key, int event )
{
    if( event != KEY_UP )	return;
    switch( key )
    {
    case VK_LEFT:
        pickleft();
        break;
    case VK_RIGHT:
 		pickright();
        break;
    case VK_UP:
    	{
			if(current==0)
			{
				if(a<4) a++;
				else if(a==4){
					initac();
					a1tf=true;
					a=1;
				} 
			}
			else if(current==2)
			{
				if(c<4) c++;
				else{
					initac();
					c1tf=true;
					c=1;
				} 	
			}	
			else if(current==3)
			{
				if(d<2) d++;
				else{
					initac();
					d1tf=true;
					d=1;
				} 		
			}	
			else if(current==4)
			{
				if(e<2) e++;
				else{
					initac();
					e1tf=true;
					e=1;
				} 		
			}	
			else if(current==5)
			{
				if(f<2) f++;
				else{
					initac();
					f1tf=true;
					f=1;
				} 			
			}	
			else if(current==6)
			{
				if(g<4) g++;
				else{
					initac();
					g1tf=true;
					g=1;
				} 			
			}	
		    break;    		
		} 

    case VK_DOWN:
    	{
			if(current==0)
			{
				int i=0;
				while(i<=3)
				{
						if(a==1) a1[i][1]+=20;
					else if(a==2) a2[i][1]+=20;
					else if(a==2) a2[i][1]+=20;
					else if(a==4) a4[i][1]+=20;			
					i++;	
				}

			}
			else if(current==1)
			{
				int i=0;
				while(i<=3)
				{
					b1[i][1]+=20;
					i++;	
				}
				
			}
			else if(current==2)
			{
				int i=0;
				while(i<=3)
				{
					if(c==1) c1[i][1]+=20;
					else if(c==2) c2[i][1]+=20;
					else if(c==2) c2[i][1]+=20;
					else if(c==4) c4[i][1]+=20;				
					i++;	
				}

			}	
			else if(current==3)
			{
				int i=0;
				while(i<=3)
				{
					if(d==1) d1[i][1]+=20;
					else if(d==2) d2[i][1]+=20;					
					i++;	
				}

			}	
			else if(current==4)
			{
				int i=0;
				while(i<=3)
				{
					if(e==1) e1[i][1]+=20;
					else if(e==2) e2[i][1]+=20;					
					i++;	
				}
	
			}	
			else if(current==5)
			{
				int i=0;
				while(i<=3)
				{
					if(f==1) f1[i][1]+=20;
					else if(f==2) f2[i][1]+=20;					
					i++;	
				}
		
			}	
			else if(current==6)
			{
				int i=0;
				while(i<=3)
				{
					if(g==1) g1[i][1]+=20;
					else if(g==2) g2[i][1]+=20;
					else if(g==2) g2[i][1]+=20;
					else if(g==4) g4[i][1]+=20;				
					i++;	
				}

			} 
			break;
	    }
	};
}
void mouseBack(int x,int y,int button,int event)
{
	if (event==0) 
	{
		if (x>=65&&x<=179&&y>=308&&y<=363)
		{
				registerTimerEvent(&downmain);    //ע�ᶨʱ����Ϣ
				startTimer(0, 300);
		}
		else if(x>=321&&x<=435&&y>=308&&y<=363) 
		{
			exit(0);
		}
	} 
} 


