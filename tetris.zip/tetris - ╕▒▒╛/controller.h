#ifndef _CONTROLLER_H_
#define _CONTROLLER_H_

#include "screen.h"
#include "model.h"
#include "view.h"
#include<stdio.h>
#include<stdlib.h>



int random();
void pickdown(int current);
void pickleft(); 
void pickright();
void over();
int down(int *x1,int *y1,int *x2,int *y2,int *x3,int *y3,int *x4,int *y4);
int left(int *x1,int *y1,int *x2,int *y2,int *x3,int *y3,int *x4,int *y4);
int right(int *x1,int *y1,int *x2,int *y2,int *x3,int *y3,int *x4,int *y4);
void downmain();
void speedModi( int key, int event ); 
void mouseBack(int x,int y,int button,int event);



#endif
