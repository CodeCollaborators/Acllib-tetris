#include "model.h"
#include "screen.h"
#include "view.h"

ACL_Sound mus;
ACL_Image img;

//ͼ��ͼƬѡ�������� 
void optiona1()
{
	loadImage("a.jpg",&img);
	
	beginPaint();
    putImage(&img,a1[0][0],a1[0][1]);
    putImage(&img,a1[1][0],a1[1][1]);
    putImage(&img,a1[2][0],a1[2][1]);
    putImage(&img,a1[3][0],a1[3][1]);
    endPaint();
} 

void optiona2()
{
	loadImage("a.jpg",&img);
	
	beginPaint();
    putImage(&img,a2[0][0],a2[0][1]);
    putImage(&img,a2[1][0],a2[1][1]);
    putImage(&img,a2[2][0],a2[2][1]);
    putImage(&img,a2[3][0],a2[3][1]);
    endPaint();
}

void optiona3()
{
	loadImage("a.jpg",&img);
	
	beginPaint();
    putImage(&img,a3[0][0],a3[0][1]);
    putImage(&img,a3[1][0],a3[1][1]);
    putImage(&img,a3[2][0],a3[2][1]);
    putImage(&img,a3[3][0],a3[3][1]);
    endPaint();
}

void optiona4()
{
	loadImage("a.jpg",&img);
	
	beginPaint();
    putImage(&img,a4[0][0],a4[0][1]);
    putImage(&img,a4[1][0],a4[1][1]);
    putImage(&img,a4[2][0],a4[2][1]);
    putImage(&img,a4[3][0],a4[3][1]);
    endPaint();
}

void optionb1()
{
	loadImage("b.jpg",&img);
	
	beginPaint();
    putImage(&img,b1[0][0],b1[0][1]);
    putImage(&img,b1[1][0],b1[1][1]);
    putImage(&img,b1[2][0],b1[2][1]);
    putImage(&img,b1[3][0],b1[3][1]);
    endPaint();
}

void optionc1()
{
	loadImage("c.jpg",&img);
	
	beginPaint();
    putImage(&img,c1[0][0],c1[0][1]);
    putImage(&img,c1[1][0],c1[1][1]);
    putImage(&img,c1[2][0],c1[2][1]);
    putImage(&img,c1[3][0],c1[3][1]);
    endPaint();
}

void optionc2()
{
	loadImage("c.jpg",&img);
	
	beginPaint();
    putImage(&img,c2[0][0],c2[0][1]);
    putImage(&img,c2[1][0],c2[1][1]);
    putImage(&img,c2[2][0],c2[2][1]);
    putImage(&img,c2[3][0],c2[3][1]);
    endPaint();
}

void optionc3()
{
	loadImage("c.jpg",&img);
	
	beginPaint();
    putImage(&img,c3[0][0],c3[0][1]);
    putImage(&img,c3[1][0],c3[1][1]);
    putImage(&img,c3[2][0],c3[2][1]);
    putImage(&img,c3[3][0],c3[3][1]);
    endPaint();
}

void optionc4()
{
	loadImage("c.jpg",&img);
	
	beginPaint();
    putImage(&img,c4[0][0],c4[0][1]);
    putImage(&img,c4[1][0],c4[1][1]);
    putImage(&img,c4[2][0],c4[2][1]);
    putImage(&img,c4[3][0],c4[3][1]);
    endPaint();
}

void optiond1()
{
	loadImage("d.jpg",&img);
	
	beginPaint();
    putImage(&img,d1[0][0],d1[0][1]);
    putImage(&img,d1[1][0],d1[1][1]);
    putImage(&img,d1[2][0],d1[2][1]);
    putImage(&img,d1[3][0],d1[3][1]);
    endPaint();
}

void optiond2()
{
	loadImage("d.jpg",&img);
	
	beginPaint();
    putImage(&img,d2[0][0],d2[0][1]);
    putImage(&img,d2[1][0],d2[1][1]);
    putImage(&img,d2[2][0],d2[2][1]);
    putImage(&img,d2[3][0],d2[3][1]);
    endPaint();
}

void optione1()
{
	loadImage("e.jpg",&img);
	
	beginPaint();
    putImage(&img,e1[0][0],e1[0][1]);
    putImage(&img,e1[1][0],e1[1][1]);
    putImage(&img,e1[2][0],e1[2][1]);
    putImage(&img,e1[3][0],e1[3][1]);
    endPaint();
}

void optione2()
{
	loadImage("e.jpg",&img);
	
	beginPaint();
    putImage(&img,e2[0][0],e2[0][1]);
    putImage(&img,e2[1][0],e2[1][1]);
    putImage(&img,e2[2][0],e2[2][1]);
    putImage(&img,e2[3][0],e2[3][1]);
    endPaint();
}

void optionf1()
{
	loadImage("f.jpg",&img);
	
	beginPaint();
    putImage(&img,f1[0][0],f1[0][1]);
    putImage(&img,f1[1][0],f1[1][1]);
    putImage(&img,f1[2][0],f1[2][1]);
    putImage(&img,f1[3][0],f1[3][1]);
    endPaint();
}

void optionf2()
{
	loadImage("f.jpg",&img);
	
	beginPaint();
    putImage(&img,f2[0][0],f2[0][1]);
    putImage(&img,f2[1][0],f2[1][1]);
    putImage(&img,f2[2][0],f2[2][1]);
    putImage(&img,f2[3][0],f2[3][1]);
    endPaint();
}

void optiong1()
{
	loadImage("g.jpg",&img);
	
	beginPaint();
    putImage(&img,g1[0][0],g1[0][1]);
    putImage(&img,g1[1][0],g1[1][1]);
    putImage(&img,g1[2][0],g1[2][1]);
    putImage(&img,g1[3][0],g1[3][1]);
    endPaint();
}

void optiong2()
{
	loadImage("g.jpg",&img);
	
	beginPaint();
    putImage(&img,g2[0][0],g2[0][1]);
    putImage(&img,g2[1][0],g2[1][1]);
    putImage(&img,g2[2][0],g2[2][1]);
    putImage(&img,g2[3][0],g2[3][1]);
    endPaint();
}

void optiong3()
{
	loadImage("g.jpg",&img);
	
	beginPaint();
    putImage(&img,g3[0][0],g3[0][1]);
    putImage(&img,g3[1][0],g3[1][1]);
    putImage(&img,g3[2][0],g3[2][1]);
    putImage(&img,g3[3][0],g3[3][1]);
    endPaint();
}

void optiong4()
{
	loadImage("g.jpg",&img);
	
	beginPaint();
    putImage(&img,g4[0][0],g4[0][1]);
    putImage(&img,g4[1][0],g4[1][1]);
    putImage(&img,g4[2][0],g4[2][1]);
    putImage(&img,g4[3][0],g4[3][1]);
    endPaint();
}
 
void chief() //��ҳ��ͼƬ 
{
	loadImage("hpage.jpg",&img);
	
	beginPaint();
    putImage(&img,0,0);
    endPaint();
}

int serch()//ѡ�������ı�Ų�����Ӧ������� 
{
	if(y10==15){
		score+=10;
		y10=0;
		return 10;
	}	
	else if(y30==15){
		score+=10;
		y30=y10;
		y10=0;
		return 30;
	}	
	else if(y50==15){
		score+=10;
		y50=y30;
		y30=y10;
		y10=0;		
		return 50;
	}	
	else if(y70==15){
		score+=10;
		y70=y50;
		y50=y30;
		y30=y10;
		y10=0;		
		return 70;
	}	
	else if(y90==15){
		score+=10;
		y90=y70;
		y70=y50;
		y50=y30;
		y30=y10;
		y10=0;			
		return 90;
	}	
	else if(y110==15){
		score+=10;
		y110=y90;
		y90=y70;
		y70=y50;
		y50=y30;
		y30=y10;
		y10=0;
		return 110;		
	}	
	else if(y130==15){
		score+=10;
		y130=y110;
		y110=y90;
		y90=y70;
		y70=y50;
		y50=y30;
		y30=y10;
		y10=0;
		return 130;		
	}	
	else if(y150==15){
		score+=10;
		y150=y130;
		y130=y110;
		y110=y90;
		y90=y70;
		y70=y50;
		y50=y30;
		y30=y10;
		y10=0;		
		return 150;
	}	
	else if(y170==15){
		score+=10;
		y170=y150;
		y150=y130;
		y130=y110;
		y110=y90;
		y90=y70;
		y70=y50;
		y50=y30;
		y30=y10;
		y10=0;
		return 170;		
	}	
	else if(y190==15){
		score+=10;
		y190=y170;
		y170=y150;
		y150=y130;
		y130=y110;
		y110=y90;
		y90=y70;
		y70=y50;
		y50=y30;
		y30=y10;
		y10=0;		
		return 190;
	}	
	else if(y210==15){
		score+=10;
		y210=y190;
		y190=y170;
		y170=y150;
		y150=y130;
		y130=y110;
		y110=y90;
		y90=y70;
		y70=y50;
		y50=y30;
		y30=y10;
		y10=0;		
		return 210;
	}	
	else if(y230==15){
		score+=10;
		y230=y210;
		y210=y190;
		y190=y170;
		y170=y150;
		y150=y130;
		y130=y110;
		y110=y90;
		y90=y70;
		y70=y50;
		y50=y30;
		y30=y10;
		y10=0;
		return 230;	
	}	
	else if(y250==15){
		score+=10;
		y250=y230;
		y230=y210;
		y210=y190;
		y190=y170;
		y170=y150;
		y150=y130;
		y130=y110;
		y110=y90;
		y90=y70;
		y70=y50;
		y50=y30;
		y30=y10;
		y10=0;
		return 250;		
	}	
	else if(y270==15){
		score+=10;
		y270=y250;
		y250=y230;
		y230=y210;
		y210=y190;
		y190=y170;
		y170=y150;
		y150=y130;
		y130=y110;
		y110=y90;
		y90=y70;
		y70=y50;
		y50=y30;
		y30=y10;
		y10=0;		
		return 270;	
	}
	else if(y290==15){
		score+=10;
		y290=y270;
		y270=y250;
		y250=y230;
		y230=y210;
		y210=y190;
		y190=y170;
		y170=y150;
		y150=y130;
		y130=y110;
		y110=y90;
		y90=y70;
		y70=y50;
		y50=y30;
		y30=y10;
		y10=0;		
		return 290;
	}	
	else if(y310==15){
		score+=10;
		y310=y290;
		y290=y270;
		y270=y250;
		y250=y230;
		y230=y210;
		y210=y190;
		y190=y170;
		y170=y150;
		y150=y130;
		y130=y110;
		y110=y90;
		y90=y70;
		y70=y50;
		y50=y30;
		y30=y10;
		y10=0;
		return 310;		
	}	
	else if(y330==15){
		score+=10;
		y330=y310;
		y310=y290;
		y290=y270;
		y270=y250;
		y250=y230;
		y230=y210;
		y210=y190;
		y190=y170;
		y170=y150;
		y150=y130;
		y130=y110;
		y110=y90;
		y90=y70;
		y70=y50;
		y50=y30;
		y30=y10;
		y10=0;
		return 330;		
	}	
	else if(y350==15){
		score+=10;
		y350=y330;
		y330=y310;
		y310=y290;
		y290=y270;
		y270=y250;
		y250=y230;
		y230=y210;
		y210=y190;
		y190=y170;
		y170=y150;
		y150=y130;
		y130=y110;
		y110=y90;
		y90=y70;
		y70=y50;
		y50=y30;
		y30=y10;
		y10=0;		
		return 350;
	}	
	else if(y370==15){
		score+=10;
		y370=y350;
		y350=y330;
		y330=y310;
		y310=y290;
		y290=y270;
		y270=y250;
		y250=y230;
		y230=y210;
		y210=y190;
		y190=y170;
		y170=y150;
		y150=y130;
		y130=y110;
		y110=y90;
		y90=y70;
		y70=y50;
		y50=y30;
		y30=y10;
		y10=0;		
		return 370;
	}	
	else if(y390==15){
		score+=10;
		y390=y370;
		y370=y350;
		y350=y330;
		y330=y310;
		y310=y290;
		y290=y270;
		y270=y250;
		y250=y230;
		y230=y210;
		y210=y190;
		y190=y170;
		y170=y150;
		y150=y130;
		y130=y110;
		y110=y90;
		y90=y70;
		y70=y50;
		y50=y30;
		y30=y10;
		y10=0;
		return 390;		
	}
	else return 0;//��ʾδ��������	
}

void rase(int linenum)//������ 
{
	int g;
	for(g=0;g<num*4;g++)
	{	
		if(list[g][3]==1&&list[g][1]<=linenum){
			//���������еĲ���
		 	if(list[g][1]==linenum){
				int j;
				for(j=0;j<15;j++){
				list[g][3]=0;
				}
			}
			//�����������Ϸ����еĲ��� 
			list[g][1]+=20;
		}
	} 	
}

void recovery()//�ػ� 
{
	int linenum=serch();
	rase(linenum);
	
	int g;
	for(g=0;g<num*4;g++)
	{
		if(list[g][3]==1)
		{
			beginPaint();
		    if(list[g][2]==1){
		    	loadImage("a.jpg",&img);
		    	putImage(&img,list[g][0],list[g][1]);
			}
			
		    else if(list[g][2]==2){
		    	loadImage("b.jpg",&img);
		    	putImage(&img,list[g][0],list[g][1]);
			}
		    else if(list[g][2]==3){
		    	loadImage("c.jpg",&img);
		    	putImage(&img,list[g][0],list[g][1]);
			}
		    else if(list[g][2]==4){
		    	loadImage("d.jpg",&img);
		    	putImage(&img,list[g][0],list[g][1]);
			}
		    else if(list[g][2]==5){
		    	loadImage("e.jpg",&img);
		    	putImage(&img,list[g][0],list[g][1]);
			}
		    else if(list[g][2]==6){
		    	loadImage("f.jpg",&img);
		    	putImage(&img,list[g][0],list[g][1]);
			}
		    else if(list[g][2]==7){
		    	loadImage("g.jpg",&img);
		    	putImage(&img,list[g][0],list[g][1]);
			}
		    endPaint();	
		}

	}

	//������ȼ����� 
	if(score/10==5&&furtf==false){
		grade++;
		furtf=true; 
	}
	else if(score/10==10&&furtf==true){
		grade++;
		furtf=false; 		
	}
	else if(score/10==15&&furtf==false){
		grade++;
		furtf=true; 		
	}
	else if(score/10==20&&furtf==true){
		grade++;
		furtf=false; 		
	}
	else if(score/10==25&&furtf==false){
		grade++;
		furtf=true; 		
	}
	else if(score/10==30&&furtf==true){
		grade++;
		furtf=false; 		
	}
	else if(score/10==35&&furtf==false){
		grade++;
		furtf=true; 		
	}
	else if(score/10==40&&furtf==true){
		grade++;
		furtf=false; 		
	}
	else if(score/10==45&&furtf==false){
		grade++;
		furtf=true; 		
	}
	else if(score/10==50&&furtf==true){
		grade++;
		furtf=false; 		
	}
	
//����Ϊֹ��û�����������浽��ô�߼��� 
	
	beginPaint();
	
	char scorecypt[20];
	char gradecypt[20];
	
	sprintf(scorecypt,"%d",score);//intת10����char 
	sprintf(gradecypt,"%d",grade);

	setTextFont("microsoft yahei");
	setTextSize(30);
	setTextColor(BLACK);
	setTextBkColor(WHITE);
	paintText(440,280,scorecypt);
	paintText(440,326,gradecypt);

	endPaint();
}

void nextimg(int xi,int yi)//��һ�� 
{
if(next==0)	
	{
		lina1( xi, yi);
		optiona1();
	}
	else if(next==1)
	{
		linb1( xi, yi);
		optionb1();
	}
	else if(next==2)
	{
		linc1( xi, yi);
		optionc1();
	}	
	else if(next==3)
	{
		lind1( xi, yi);
		optiond1();	
	}	
	else if(next==4)
	{
		line1( xi, yi);
		optione1();		
	}	
	else if(next==5)
	{
		linf1( xi, yi);
		optionf1();
	}	
	else if(next==6)
	{		
		ling1( xi, yi);
		optiong1();
	}	
}

void minor() //��Ϸ�������ͼ 
{
	loadImage("spage.jpg",&img);
	
	beginPaint();
    putImage(&img,0,0);
    endPaint();
}

void gameover()
{
	loadImage("over.jpg",&img);
	
	beginPaint();
    putImage(&img,0,0);
    endPaint();	
}

void actionmusic()
{
	loadSound("hello.mp3",&mus);
	playSound(0,1);
}
